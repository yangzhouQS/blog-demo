'use strict';

exports.logger = {
  coreLogger: {
    consoleLevel: 'WARN',
  },
};
