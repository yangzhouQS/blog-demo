'use strict';

module.exports = {
  logger: {
    consoleLevel: 'WARN',
    buffer: false,
  },
};
