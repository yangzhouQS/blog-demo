'use strict';

module.exports = require('koa-bodyparser');
