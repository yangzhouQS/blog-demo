'use strict';

module.exports = require('koa-override');
