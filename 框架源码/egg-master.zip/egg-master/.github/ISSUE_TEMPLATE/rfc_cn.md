---
name: 'RFC Proposals'
about: 'Provide a solution for this project'
title: '[RFC] say something'
labels: 'type: proposals'
assignees: ''

---

<!-- 相关 RFC 示例：https://git.io/fphwy -->

## 背景

> 描述你希望解决的问题的现状，附上相关的 issue 地址

## 思路

> 描述大概的解决思路，可以包含 API 设计和伪代码等

## 跟进

- [ ] some task
- [ ] PR URL
