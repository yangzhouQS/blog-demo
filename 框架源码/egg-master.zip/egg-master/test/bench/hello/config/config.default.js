'use strict';

exports.keys = 'hello app';

exports.security = {
  csrf: false,
};
