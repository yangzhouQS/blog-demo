export default {
  keys: 'foo',
  serverTimeout: 2 * 60 * 1000,
}
