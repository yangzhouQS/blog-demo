exports.siteFile = {
  '/favicon.ico': 'https://eggjs.org/favicon.ico',
}

exports.keys = 'foo';
