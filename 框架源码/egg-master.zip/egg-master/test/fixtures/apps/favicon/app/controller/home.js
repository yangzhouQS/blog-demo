'use strict';

module.exports = function*() {
  this.body = 'home';
};
