'use strict';

exports.keys = 'fo';

exports.security = {
  csrf: false,
  debug: 'csrf-disable',
};
