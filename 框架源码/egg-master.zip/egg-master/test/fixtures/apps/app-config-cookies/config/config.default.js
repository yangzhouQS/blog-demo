'use strict';

exports.keys = 'test key';

exports.cookies = {
  sameSite: 'lax',
};
