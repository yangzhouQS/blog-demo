'use strict';

exports.logger = {
  consoleLevel: 'NONE',
};
