
module.exports = function* () {
  this.session = null;
  this.body = 'clear';
};
