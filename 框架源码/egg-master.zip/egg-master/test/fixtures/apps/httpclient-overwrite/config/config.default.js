'use strict';

exports.httpclient = {
  request: {
    timeout: 100,
  },
};
