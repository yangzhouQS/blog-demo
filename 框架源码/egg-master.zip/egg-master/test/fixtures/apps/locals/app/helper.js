'use strict';

exports.test = () => {
  return 'test-helper';
};
