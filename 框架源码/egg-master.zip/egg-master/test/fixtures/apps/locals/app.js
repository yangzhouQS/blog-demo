module.exports = app => {
  app.locals = {
    'app.global' : {
      'id': '12306',
      'version': '1.0'
    },
    a: 1,
    b: 1,
  };
};
