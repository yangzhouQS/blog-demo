exports.bodyParser = {
  match: '/test/body_parser/foo.json',
};

exports.security = {
  csrf: false,
};

exports.keys = 'foo';
