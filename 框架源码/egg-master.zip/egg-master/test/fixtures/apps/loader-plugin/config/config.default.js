exports.plugin = 'override plugin';

exports.middleware = [];

exports.keys = 'test key';
