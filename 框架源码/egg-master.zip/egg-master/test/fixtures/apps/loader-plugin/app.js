'use strict';

module.exports = app => {
  app.date = Date.now();
  app.app = 'app';
};
