'use strict';

module.exports = function (app) {
  class Foo extends app.Service {

  }

  return Foo;
};
