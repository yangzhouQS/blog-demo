module.exports = function*() {
  return 'foo2';
};
