module.exports = function*() {
  return 'foo3';
};
