'use strict';

module.exports = function (app) {
  class Foo4 extends app.Service {

  }

  return Foo4;
};
