'use strict';

module.exports = function (app) {
  class Foo5 extends app.Service {

  }

  return Foo5;
};
