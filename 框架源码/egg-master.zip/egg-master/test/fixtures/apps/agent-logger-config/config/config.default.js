'use strict';

module.exports = {
  logger: {
    dir: '/tmp/foo',
  },
};
