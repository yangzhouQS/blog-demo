'use strict';

module.exports = app => {
  app['aliyun-egg'] = {};
};
