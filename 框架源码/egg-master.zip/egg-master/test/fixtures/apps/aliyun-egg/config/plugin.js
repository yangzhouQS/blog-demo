'use strict';

const path = require('path');

module.exports = {
  custom: {
    enable: true,
    path: path.join(__dirname, '../lib/plugins/custom'),
  },
};
