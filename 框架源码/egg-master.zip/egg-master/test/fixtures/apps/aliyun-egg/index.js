'use strict';

const egg = require('../../../..');

module.exports = egg;
module.exports.Application = require('./lib/aliyun-egg');
module.exports.Agent = require('./lib/agent');
