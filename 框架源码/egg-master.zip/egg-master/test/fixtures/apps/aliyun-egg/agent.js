'use strict';

module.exports = agent => {

};
