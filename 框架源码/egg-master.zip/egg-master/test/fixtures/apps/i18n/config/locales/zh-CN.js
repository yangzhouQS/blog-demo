module.exports = {
  'Email': '邮箱',
  'Hello %s, how are you today?': '%s，今天过得如何？',
};
