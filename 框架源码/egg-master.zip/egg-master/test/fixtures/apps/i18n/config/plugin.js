'use strict';

module.exports = {
  i18n: true,
  nunjucks: {
    enable: true,
    package: 'egg-view-nunjucks',
  }
};
