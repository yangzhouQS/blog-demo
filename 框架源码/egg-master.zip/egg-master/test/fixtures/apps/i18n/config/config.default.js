'use strict';

exports.view = {
  defaultViewEngine: 'nunjucks',
};

exports.keys = 'test key';
