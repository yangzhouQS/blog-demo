exports.keys = 'foo';

exports.security = {
  csrf: {
    enable: false,
  },
};
