'use strict';

exports.workerStartTimeout = 1000;
