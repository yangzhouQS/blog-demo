'use stirct';

exports.logger = {
  stdoutLevel: 'NONE',
};
