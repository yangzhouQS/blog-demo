module.exports = {
  foo: 1,
  bar: function() {
    return 2;
  }
};