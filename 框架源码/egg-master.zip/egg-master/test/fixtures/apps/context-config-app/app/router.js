module.exports = app => {
  app.get('home', '/', 'home.index');
};
