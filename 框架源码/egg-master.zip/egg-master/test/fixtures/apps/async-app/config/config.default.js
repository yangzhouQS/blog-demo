'use strict';

exports.keys = 'key';
exports.middleware = [ 'async' ];
