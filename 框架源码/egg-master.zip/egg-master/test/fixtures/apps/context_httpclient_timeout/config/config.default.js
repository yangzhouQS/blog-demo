'use strict';

exports.keys = 'test key';

exports.httpclient = {
  httpAgent: {
    timeout: 1000,
  },
};
