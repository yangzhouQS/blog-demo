exports.bodyParser = {
  formLimit: '100kb',
  jsonLimit: '100kb',
  textLimit: '100kb',
  queryString: {
    arrayLimit: 5
  }
};

exports.keys = 'foo';
