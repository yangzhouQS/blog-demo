'use strict';

exports.keys = 'test key';
