export default class Test {}
