'use strict';

exports.httpclient = {
  enableDNSCache: true,
  dnsCacheLookupInterval: 5000,
};

exports.keys = 'test key';
