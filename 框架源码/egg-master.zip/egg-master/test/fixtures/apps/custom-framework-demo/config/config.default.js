exports.keys = 'foo';
exports.proxy = true;
exports.buffer = Buffer.from('test');

exports.pass = 'this is pass';
exports.pwd = 'this is pwd';
exports.password = 'this is password';
exports.passwordNew = 'this is passwordNew';
exports.mysql = {
  passd: 'this is passd',
  passwd: 'this is passwd',
  secret: 'secret 123',
  secretNumber: 123,
  secretBoolean: true,
  masterKey: 'this is masterKey',
  accessKey: 'this is accessKey',
  accessId: 'this is accessId',
  consumerSecret: 'this is consumerSecret',
  someSecret: null,
};

exports.tips = 'hello egg';
