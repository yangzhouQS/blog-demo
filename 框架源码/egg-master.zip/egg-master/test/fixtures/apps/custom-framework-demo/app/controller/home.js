module.exports = function* () {
  this.body = {
    workerTitle: process.title
  };
};
