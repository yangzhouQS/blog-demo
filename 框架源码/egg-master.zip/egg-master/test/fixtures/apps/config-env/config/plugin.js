'use strict';

exports.static = false;
