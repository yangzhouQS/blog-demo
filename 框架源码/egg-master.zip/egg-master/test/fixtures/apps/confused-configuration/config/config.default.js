'use strict';

exports.middlewares = [];
exports.bodyparser = {};
exports.sitefile = {};
exports.notFound = {};
exports.httpClient = {};
