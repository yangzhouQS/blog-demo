module.exports = {
  ready: cb => cb(),
};
