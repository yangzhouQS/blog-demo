exports.bodyParser = {
  enable: false,
};

exports.security = {
  csrf: false,
};

exports.keys = 'foo';
