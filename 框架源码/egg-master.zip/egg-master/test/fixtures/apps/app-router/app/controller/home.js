module.exports = function* () {
  this.body = 'hello';
};
