'use strict';

module.exports = {
  tracer: {
    enable: true,
    package: 'egg-tracer',
  },
}
