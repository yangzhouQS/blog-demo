module.exports = function* () {
  this.body = 'hello home';
};
