'use strict';

module.exports = () => {
  return {
    mock: {
      name: 'mock',
    },
  };
}
