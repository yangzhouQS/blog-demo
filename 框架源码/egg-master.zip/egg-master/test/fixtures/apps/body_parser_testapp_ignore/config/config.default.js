exports.bodyParser = {
  ignore: '/test/body_parser/foo.json',
};

exports.security = {
  csrf: false,
};

exports.keys = 'foo';
