'use strict';

const path = require('path');

module.exports = {
  keys: 'test key',
  middleware: [ 'koastatic' ],
};
