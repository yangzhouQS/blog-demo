'use strict';

module.exports = require('../aliyun-egg');
