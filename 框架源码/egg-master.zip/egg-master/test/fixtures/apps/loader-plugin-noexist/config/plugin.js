'use strict';

module.exports = {
  noexist: true
};
