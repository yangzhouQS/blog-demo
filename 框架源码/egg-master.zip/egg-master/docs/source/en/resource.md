title: Resources
---

* [awesome-egg](https://github.com/eggjs/awesome-egg)

## Frameworks

* [aliyun-egg](https://github.com/eggjs/aliyun-egg)

## Community Articles

* [How to evaluate Ali's open source enterprise-level Node.js framework Egg?](https://www.zhihu.com/question/50526101/answer/144952130)
  By [@day pig](https://github.com/atian25)

* You can also read our article at [Kuroshiami column](https://zhuanlan.zhihu.com/eggjs)

## Tools

* [vscode plugin - eggjs](https://marketplace.visualstudio.com/items?itemName=atian25.eggjs)
* [vscode plugin - eggjs-dev-tools](https://marketplace.visualstudio.com/items?itemName=yuzukwok.eggjs-dev-tools)