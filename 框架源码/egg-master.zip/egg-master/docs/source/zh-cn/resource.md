title: 资源
---

- [awesome-egg](https://github.com/eggjs/awesome-egg)

## 框架列表

- [aliyun-egg](https://github.com/eggjs/aliyun-egg)

## 社区文章

- [如何评价阿里开源的企业级 Node.js 框架 Egg？](https://www.zhihu.com/question/50526101/answer/144952130)
by [@天猪](https://github.com/atian25)

- 你也可以到[知乎专栏](https://zhuanlan.zhihu.com/eggjs)看我们的文章

## 工具

- [vscode plugin - eggjs](https://marketplace.visualstudio.com/items?itemName=atian25.eggjs)
- [vscode plugin - eggjs-dev-tools](https://marketplace.visualstudio.com/items?itemName=yuzukwok.eggjs-dev-tools)