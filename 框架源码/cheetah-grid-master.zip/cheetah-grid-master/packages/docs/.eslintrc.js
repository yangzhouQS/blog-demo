'use strict'

module.exports = require('../../eslint/eslint-config-vue.js')