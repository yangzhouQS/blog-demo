# API for JavaScript

- [Headers and Columns](./headers_columns.md)
- [Grid Data](./grid_data/README.md)
- [Selection](./selection.md)
- [Events](./events.md)
