---
order: 500
---

# Advanced Header

You can extend the header.

- [Sort by Column](./column_sort.md)
- [Header Actions](./header_actions.md)
