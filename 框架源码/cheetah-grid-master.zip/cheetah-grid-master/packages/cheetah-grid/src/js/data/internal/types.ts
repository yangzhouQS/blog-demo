import type { MaybePromiseOrUndef } from "../../ts-types";

export type PromiseCacheValue<V> = MaybePromiseOrUndef<V>;
