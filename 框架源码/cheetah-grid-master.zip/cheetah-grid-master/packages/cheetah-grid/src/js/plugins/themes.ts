import type { Theme } from "../themes/theme";

export const themes: { [key: string]: Theme } = {};
