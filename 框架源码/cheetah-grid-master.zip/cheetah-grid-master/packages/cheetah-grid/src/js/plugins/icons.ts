import type { IconDefine } from "../ts-types";

export const icons: { [key: string]: IconDefine } = {};
