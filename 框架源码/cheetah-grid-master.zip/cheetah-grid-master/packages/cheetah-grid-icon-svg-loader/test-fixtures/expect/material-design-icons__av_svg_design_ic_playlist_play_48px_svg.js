var obj={
 "ic_playlist_play_48px": {
  "d": "M8,20 h24 v4 h-24zM8,12 h24 v4 h-24zM8,28 h16 v4 h-16zM28,28 28,40 38,34 \t\tz",
  "width": 0,
  "height": 0
 }
}
  if (typeof window !== 'undefined') {
    window['material-design-icons__av_svg_design_ic_playlist_play_48px_svg']=obj
  } else {
    module.exports=obj
  }
  