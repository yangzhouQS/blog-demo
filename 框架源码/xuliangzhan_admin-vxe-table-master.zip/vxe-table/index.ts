import './styles/index.scss'
import VXETable from './packages/vxe-table'

export * from './packages/vxe-table'
export default VXETable
