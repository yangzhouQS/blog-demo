import VXETable from '../types/vxe-table'

export * from '../types/vxe-table'

export default VXETable
