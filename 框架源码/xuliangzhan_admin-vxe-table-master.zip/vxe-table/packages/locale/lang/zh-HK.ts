import zhTC from './zh-TC'

export default zhTC
