export const Icon = {
  /* eslint-disable @typescript-eslint/no-empty-function */
  install () {}
}

export default Icon
