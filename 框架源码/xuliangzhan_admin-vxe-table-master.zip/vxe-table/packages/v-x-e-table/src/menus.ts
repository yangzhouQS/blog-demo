import VXEStore from './store'

import { Menus } from '../../../types/v-x-e-table'

const menus = new VXEStore() as Menus

export default menus
