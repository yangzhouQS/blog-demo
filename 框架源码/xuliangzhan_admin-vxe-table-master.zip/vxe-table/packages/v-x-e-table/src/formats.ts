import VXEStore from './store'

import { VxeGlobalFormats } from '../../../types/v-x-e-table'

const formats = new VXEStore() as VxeGlobalFormats

export default formats
