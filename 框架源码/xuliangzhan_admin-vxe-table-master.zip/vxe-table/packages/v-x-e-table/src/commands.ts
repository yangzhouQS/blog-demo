import VXEStore from './store'

import { VxeGlobalCommands } from '../../../types/v-x-e-table'

const commands = new VXEStore() as VxeGlobalCommands

export default commands
