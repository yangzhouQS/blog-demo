import VXEStore from './store'

import { VxeGlobalHooks } from '../../../types/v-x-e-table'

const hooks = new VXEStore() as VxeGlobalHooks

export default hooks
