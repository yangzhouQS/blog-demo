---
name: Feature request
about: 功能需求：这个需求解决了什么问题？
title: ''
labels: enhancement
assignees: ''

---

**（必填）这个需求解决了什么问题：**
？

**截图或在线链接：**
？

**建议的 API 是什么样的：**
？

**是否已有其他不错的替代方案：**
？
