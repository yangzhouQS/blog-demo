---
name: Bug report
about: 反馈问题：请将问题的重现步骤描述清楚！
title: ''
labels: bug
assignees: ''

---

**（必填）请填写问题描述或截图：**
？

**（必填）请填在线链接：**
？

**（必填）请填写期望的结果：**
？

**（必填）请填写以下信息：**

- OS: ？
- Browser: ？
- vue: ？
- vxe-table: ？
