import VXETable from './vxe-table'

export * from './vxe-table'

export default VXETable
