import { VXETableComponent } from './component'

/**
 * 表格扩展 - 表头
 */
export interface Header extends VXETableComponent {}
