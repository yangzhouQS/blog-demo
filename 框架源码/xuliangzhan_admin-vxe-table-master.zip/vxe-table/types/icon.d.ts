import { VXETableComponent } from './component'

/**
 * 组件 - 图标库
 */
export interface Icon extends VXETableComponent {}
