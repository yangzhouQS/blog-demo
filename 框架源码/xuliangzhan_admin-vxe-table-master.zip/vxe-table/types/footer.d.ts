import { VXETableComponent } from './component'
import { VxeTableDefines } from './table'

/**
 * 表格扩展 - 表尾
 */
export interface Footer extends VXETableComponent {}
