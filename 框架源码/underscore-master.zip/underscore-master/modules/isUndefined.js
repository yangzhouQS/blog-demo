// Is a given variable undefined?
export default function isUndefined(obj) {
  return obj === void 0;
}
