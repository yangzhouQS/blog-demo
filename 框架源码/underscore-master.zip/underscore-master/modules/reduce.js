import createReduce from './_createReduce.js';

// **Reduce** builds up a single result from a list of values, aka `inject`,
// or `foldl`.
export default createReduce(1);
