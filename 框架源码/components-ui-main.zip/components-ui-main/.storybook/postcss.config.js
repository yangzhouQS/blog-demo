module.exports = {
  plugins: [
    require('autoprefixer'),
    require('tailwindcss'),
    require('postcss-nested'),
    require('postcss-preset-env'),
  ],
};
