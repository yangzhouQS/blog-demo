# Descrição

Descrição do que é esperado deste PR

## Stories relacionadas (clubhouse)

- [ch-xxx]

## Pontos para atenção

- Listar pontos para atenção no review
- Listar pontos para atenção nos testes

## Possui novas configurações?

- Descrever as configurações alteradas ou novas

## Possui migrations?

- Se a feature adicionou alguma _migration_ e como faz para rodar
