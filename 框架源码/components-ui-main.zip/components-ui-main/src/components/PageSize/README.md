**Demo**

```html
<PageSize v-model="size" @change="handleChange" />
```

| Prop name | Type     | Required | Default |
| --------- | -------- | -------- | ------- |
| id        | `String` | `true`   | ---     |
| value     | `Number` | `true`   | ---     |

**Number return page size value - @change**

```js
10;
```
