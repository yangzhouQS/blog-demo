**Demo**

```js
<Badge variant="done">Concluido</Badge>
<Badge hidden-icon variant="done">Concluido</Badge>
```

**Variants**

```js
[
  'done',
  'denied',
  'review',
  'in-progress',
  'approved',
  'message',
  'message-line',
];
```
