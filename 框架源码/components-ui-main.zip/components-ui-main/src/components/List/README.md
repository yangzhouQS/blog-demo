**Demo**

```js
<List
  :items-list="itemsList"
/>
```

**example items list**

```js
itemsList:[
  {
    title: 'Lorem ipsum dolor',
    description: 'Vivamus luctus ipsum sed sapien tristique',
  },
  {
    title: 'Lorem ipsum dolor',
    description: 'Vivamus luctus ipsum sed sapien tristique',
  },
  {
    title: 'Lorem ipsum dolor',
    description: 'Vivamus luctus ipsum sed sapien tristique',
  },
],
```
