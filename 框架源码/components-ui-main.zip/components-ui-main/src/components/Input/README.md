**Demo**

```html
<input
  id="search"
  v-model="search"
  type="search"
  name="search"
  placeholder="Busque por"
  @eventHandler="triggerFunction"
/>
```
