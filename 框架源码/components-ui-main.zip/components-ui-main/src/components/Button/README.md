**Demo**

```js
<Button>Button</Button>
<Button disabled>Button</Button>
<Button variant="secondary">Button</Button>
<Button variant="secondary" disabled>Button</Button>
<Button variant="exception">Button</Button>
<Button variant="exception" disabled>Button</Button>
```
