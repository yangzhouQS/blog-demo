// some modules with missing type definitions
declare module 'less';
declare module 'sass';
declare module 'execa';
declare module 'hash-sum';
declare module 'clean-css';
declare module 'webpackbar';
declare module 'release-it';
declare module 'html-webpack-plugin';
declare module 'conventional-changelog';
declare module '@vant/markdown-vetur';
declare module '@nuxt/friendly-errors-webpack-plugin';
