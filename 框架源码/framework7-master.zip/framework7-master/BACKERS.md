# Backers

<table>
  <tr>
    <td align="center" valign="middle">
      <a href="https://www.wfmbuddy.com/" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/wfmbuddy.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://www.codefirst.co.uk" target="_blank">
        <img src="https://framework7.io/i/sponsors/codefirst.png" alt="Software Development Company | CodeFirst UK" width="160">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://privicy.com/" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/privicy.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://www.thoriumbuilder.com/" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/thorium.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://app-valley.vip/" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/appvalley.jpg">
      </a>
    </td>
  </tr>
  <tr>
    <td align="center" valign="middle">
      <a href="http://mytommy.com" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/tommy.png">
      </a>
    </td>
    <td>
      <a href="https://www.ramotion.com/agency/app-development/" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/ramotion.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://findmate.app" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/findmate.png">
      </a>
    </td>
    <td>
      <a href="https://goread.io/buy-instagram-likes" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/goread.png">
      </a>
    </td>
    <td>
      <a href="https://www.coupons4printing.com" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/coupons4printing.jpg">
      </a>
    </td>
  </tr>
  <tr>
    <td align="center" valign="middle">
      <a href="https://www.collegepaperworld.com/research-paper.html" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/collegeresearchpaper.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://casinofiables.com/" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/casinofiables.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://www.gunsbet.com" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/gunsbet.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://www.realtimecommunicationsworld.com" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/realtime.jpg">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://vpn-review.com/vpn-for-torrenting" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/vpn.png">
      </a>
    </td>
  </tr>
  <tr>
    <td align="center" valign="middle">
      <a href="https://tutlance.com" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/tutlance.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://edubirdie.com" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/edubirdie.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://uppsats.eu" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/uppsats.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://www.bonus.com.de/" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/bonusfinder.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://kqapi.us" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/kqapius.png">
      </a>
    </td>
  </tr>
  <tr>
    <td align="center" valign="middle">
      <a href="https://writersperhour.com/write-my-paper" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/writersperhour.jpg">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://www.colognewebdesign.de/" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/colognewebdesign.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://rise.co" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/rise.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://usave.co.uk/utilities/broadband" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/usave.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://bid4papers.com/write-my-essay.html" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/bid4papers.png">
      </a>
    </td>
  </tr>
  <tr>
    <td align="center" valign="middle">
      <a href="https://kidoverse.app" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/kidoverse.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://www.cyberbrain.nl/" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/cyberbrain.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://hicapps.cl/" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/hicapps.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://blokt.com/" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/blokt.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="https://wappler.io/" target="_blank">
        <img width="160" src="https://framework7.io/i/sponsors/wappler.png">
      </a>
    </td>
  </tr>
</table>

Support Framework7 development by [pledging on Patreon](https://www.patreon.com/vladimirkharlampidi)!

### \$1000 Diamond Sponsor

[Currently vacant. It could be you!](https://www.patreon.com/bePatron?patAmt=1000.0&exp=1&u=4109762&rid=830901)

---

### \$500 Platinum Sponsor

[Currently vacant. It could be you!](https://www.patreon.com/bePatron?patAmt=500.0&exp=1&u=4109762&rid=830876)

---

### \$250 Gold Sponsor

[WFM Buddy](https://www.wfmbuddy.com/) - WFM Buddy - Delighting your Workforce<br>

[Join here!](https://www.patreon.com/bePatron?patAmt=250.0&exp=1&u=4109762&rid=830877)

---

### \$100 Silver Sponsor

[Ramotion](https://www.ramotion.com/agency/app-development/) - App Development Agency<br>
[Thorium Builder](https://www.thoriumbuilder.com/) - Full visual Framework7 app builder<br>
Colin Adams ([App Valley](https://appvalley.vip/))<br>
Mason Fok ([tommy](http://mytommy.com))<br>

[Join here!](https://www.patreon.com/bePatron?patAmt=100.0&exp=1&u=4109762&rid=830841)

---

### \$50+ Top Supporter

[CodeFirst](https://www.codefirst.co.uk) - Software Development Company | CodeFirst UK<br>
[Privicy](https://privicy.com/) - Privacy control for consumers<br>
[Buy Instagram Likes from Goread](https://goread.io/buy-instagram-likes)<br>
[Coupons4Printing: Promotion Codes, Coupons, Coupon Codes](https://www.coupons4printing.com)<br>
SIMPLY LAB<br>
[College Papers for Sale | Buy Research Paper Online](https://www.collegepaperworld.com/research-paper.html)<br>
[Casino En Ligne Canada, Les Meilleurs Casinos Virtuels Canadiens](https://casinofiables.com/)<br>
[GunsBet Casino](https://www.gunsbet.com)<br>
[Real Time Communications World](https://www.realtimecommunicationsworld.com)<br>
[Tutlance.com - Pay For Homework Answers, Assignments and Essay Solutions](https://tutlance.com)<br>
[EduBirdie - The professional essay writing service for students who can't even](https://edubirdie.com)<br>
[Findmate - International Dating](https://findmate.app)<br>
[Tjänst för akademisk skrivning. Beställ din uppsats](https://uppsats.eu)<br>
[www.bonus.com.de](https://www.bonus.com.de/)<br>
[Writers Per Hour](https://writersperhour.com/write-my-paper) - Write My Paper For Me<br>
[Bid4Papers](https://bid4papers.com/write-my-essay.html) - Write My Essay<br>
[COLOGNE WEBDESIGN](https://www.colognewebdesign.de/)<br>
[Kqapius, INC.](https://kqapi.us)<br>
[Rise](https://rise.co) - Creative Web Development Agency<br>
[usave](https://usave.co.uk/utilities/broadband) - compare broadband deals on usave.co.uk<br>
[Kidoverse](https://kidoverse.app) - App for kids to learn, play, create and explore<br>
[CyberBrain IT Services](https://www.cyberbrain.nl/)<br>
[HICAPPS](https://hicapps.cl/) - Health Informatics Custom APPs<br>
Michael Russell<br>
[Blokt](https://blokt.com/) - Cryptocurrency News<br>
Alexey Victorov<br>
[Wappler](https://wappler.io) - Visual Web App Creator, offers full visual Framework7 builder<br>
Marcelo Lopetegui L.<br>
Bearr Dayss<br>
Kris Reddy<br>
Bart DJ

[Join here!](https://www.patreon.com/bePatron?exp=1&rid=830842&u=4109762&patAmt=50.0)

---

### \$25+ Awesome Supporter

Danny Redfern<br>

[Join here!](https://www.patreon.com/join/vladimirkharlampidi/checkout?rid=4656325)

---

### \$10+ Supporter

Franz Gusenbauer<br>
loopcake<br>
Jim Leliveld<br>
Wolfgang Bochar<br>
Picolé de Chuchu<br>
Stan Smulders<br>
Lailton Fernando Mariano<br>
User Mail<br>
Thomason<br>
Shawn Jackson<br>
Никита Коробочкин<br>
Nathan Harold<br>
iOS Haven<br>
JK<br>
Azad Zain<br>
Will Mero<br>
Jorge Pagano<br>
Jacob Gur<br>
Matthew Proctor<br>
Andy Fuchs<br>
Noah A Neibaron<br>
José Manuel Alarcón<br>
Matt Davis<br>
Arsen Huang<br>
Marc Hildmann<br>
VOUSYS<br>
Almaz Kazakov<br>
plpl<br>
Dan Boschen<br>
Ferry van de Graaf<br>
Denis Bousselier<br>
Matthew Becker<br>
Timo Ernst<br>
Dave Billington

[Join here!](https://www.patreon.com/bePatron?exp=1&rid=830839&u=4109762&patAmt=10.0)

---

### \$5+ Thank You

Ivan Ivanco<br>
T Konink<br>
Elijah Jahbless<br>
emre çete<br>
Yo. Meyers<br>
Brett Lee<br>
Miguel Nahara<br>
Muthaiyan Rm<br>
xPlants.it SRL<br>
Mamadou Ndiaye<br>
LitoMore<br>
Jacob Rosenberg<br>
Farshid Mossaiby<br>
Byron<br>
Evgeny Konyahin<br>
jinsom<br>
Alessandro De Siro<br>
Simon MacDonald<br>
César Teixeira<br>
Firas Sleibi<br>
Garry Lowther<br>
Tirso Martínez Reyes<br>
Amir br<br>
Toby Allen - Ballymaloe Cookery School<br>
Henry Blackman<br>
Ruslan Skorynin<br>
Hayl Ltd

[Join here!](https://www.patreon.com/bePatron?exp=1&rid=845389&u=4109762&patAmt=5.0)
