/**
 * Hardware graphics API renderer.
 */
export interface IHardwareRenderer {
  // todo: implements
  [key: string]: any;
}
