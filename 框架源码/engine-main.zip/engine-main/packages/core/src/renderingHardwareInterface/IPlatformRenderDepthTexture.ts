import { IPlatformTexture } from "./IPlatformTexture";

/**
 * Rendering depth texture interface specification.
 */
export interface IPlatformRenderDepthTexture extends IPlatformTexture {}
