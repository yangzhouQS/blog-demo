import "./Extension";
import { ShadowFeature } from "./ShadowFeature";
import { Scene } from "../Scene";

Scene.registerFeature(ShadowFeature);
