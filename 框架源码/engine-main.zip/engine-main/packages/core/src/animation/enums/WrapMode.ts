/**
 * Animation wrap mode.
 */
export enum WrapMode {
  /** Play once */
  Once = 0,
  /** Loop play */
  Loop = 1
}
