export enum AnimatorLayerBlendingMode {
  Override,
  Additive
}
