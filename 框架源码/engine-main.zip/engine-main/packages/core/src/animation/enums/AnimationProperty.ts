export enum AnimationProperty {
  Position,
  Rotation,
  Scale,
  BlendShapeWeights
}
