export enum AnimatorConditionMode {
  If,
  IfNot,
  Greater,
  Less,
  Equals,
  NotEquals
}
