/**
 * Base class for AnimationClips and BlendTrees.
 */
export class Motion {}
