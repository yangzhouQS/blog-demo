export type { IPlatformPrimitive } from "./IPlatformPrimitive";
