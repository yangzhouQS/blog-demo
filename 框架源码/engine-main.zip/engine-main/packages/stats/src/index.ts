import { Engine } from "oasis-engine";
import { Stats } from "./Stats";

Engine.registerFeature(Stats);

export { Stats };
