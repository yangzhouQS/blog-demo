<template>
  <va-checkbox v-model="value" indeterminate />
</template>

<script>
export default {
  data () {
    return {
      value: true,
    }
  },
}
</script>
