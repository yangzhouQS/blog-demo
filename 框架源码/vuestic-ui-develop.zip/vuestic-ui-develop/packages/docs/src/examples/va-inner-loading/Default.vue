<template>
  <va-inner-loading :loading="true">
    <va-card>
      <va-card-title>Title</va-card-title>
      <va-card-content>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</va-card-content>
    </va-card>
  </va-inner-loading>
</template>
