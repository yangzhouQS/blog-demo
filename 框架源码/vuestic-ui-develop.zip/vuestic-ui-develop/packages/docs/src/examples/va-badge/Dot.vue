<template>
  <div class="example">
    <va-badge overlap dot>
      <template #text>
        <va-icon name="warning" size="12px" />
      </template>
      <va-icon name="account_box" size="30px" />
    </va-badge>
  </div>
</template>
