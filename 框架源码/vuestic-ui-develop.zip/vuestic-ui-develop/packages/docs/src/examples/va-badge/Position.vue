<template>
  <div class="example">
    <va-badge left text="99+" class="mr-4">
      <va-button size="small">Left</va-button>
    </va-badge>
    <va-badge bottom text="99+" class="mr-4">
      <va-button size="small">Bottom</va-button>
    </va-badge>
  </div>
</template>
