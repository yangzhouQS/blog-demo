<template>
  <div>
    <va-badge class="mr-4" transparent overlap text="+1">
      <va-icon name="face" size="30px" />
    </va-badge>

    <va-badge transparent overlap>
      <template #text>
        <va-icon name="warning" size="12px" />
      </template>
      <va-icon name="account_box" size="30px" />
    </va-badge>
  </div>
</template>
