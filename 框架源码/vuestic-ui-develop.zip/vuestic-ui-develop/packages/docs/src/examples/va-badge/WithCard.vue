<template>
  <div>
    <va-badge text="New" overlap>
      <va-card>
        <va-card-content>
          Next update is right behind the corner
        </va-card-content>
      </va-card>
    </va-badge>
  </div>
</template>
