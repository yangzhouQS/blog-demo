<template>
  <div class="example">
    <va-badge text="warning" color="warning" class="mr-4" />
    <va-badge text="#ad0" color="#ad0" class="mr-4" />
    <va-badge text="black text" text-color="black" class="mr-4" />
  </div>
</template>
