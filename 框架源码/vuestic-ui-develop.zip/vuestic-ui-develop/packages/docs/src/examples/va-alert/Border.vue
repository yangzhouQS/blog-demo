<template>
  <div>
    <va-alert border="top" class="mb-4">
      You read this important alert message.
    </va-alert>
    <va-alert color="success" border="right" class="mb-4">
      You successfully read this important alert message.
    </va-alert>
    <va-alert color="info" border="bottom" class="mb-4">
      This alert needs your attention, but it's not super important.
    </va-alert>
    <va-alert color="warning" border="left" class="mb-4">
      Better check yourself, you're not looking too good.
    </va-alert>
    <va-alert color="gray" border="top" border-color="danger" class="mb-4">
      Change a few things up and try submitting again.
    </va-alert>
  </div>
</template>
