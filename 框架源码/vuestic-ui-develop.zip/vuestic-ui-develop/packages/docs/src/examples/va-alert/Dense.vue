<template>
  <div>
    <va-alert dense color="success" class="mb-4">
      Dense alert.
    </va-alert>
    <va-alert dense color="info" class="mb-4">
      Alert with color style.
    </va-alert>
    <va-alert dense color="warning" outline class="mb-4">
      Alert with outline style.
    </va-alert>
    <va-alert dense color="danger" border="top" border-color="danger" class="mb-4">
      Alert with colorful border.
    </va-alert>
  </div>
</template>
