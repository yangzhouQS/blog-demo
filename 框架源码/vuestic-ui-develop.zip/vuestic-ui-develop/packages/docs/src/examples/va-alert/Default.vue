<template>
  <div>
    <va-alert class="mb-4" description="You read this important alert message." />
    <va-alert>
      You read this important slotted alert message.
    </va-alert>
  </div>
</template>
