<template>
  <div>
    <va-alert class="mb-4">
      You read this important alert message.
    </va-alert>
    <va-alert color="success" class="mb-4">
      You successfully read this important alert message.
    </va-alert>
    <va-alert color="info" class="mb-4">
      This alert needs your attention, but it's not super important.
    </va-alert>
    <va-alert color="warning" class="mb-4">
      Better check yourself, you're not looking too good.
    </va-alert>
    <va-alert color="danger" class="mb-4">
      Change a few things up and try submitting again.
    </va-alert>
    <va-alert color="#692BEB" class="mb-4">
      Better check yourself, you're not looking too good.
    </va-alert>
    <va-alert color="#540C0C" class="mb-4">
      Change a few things up and try submitting again.
    </va-alert>
  </div>
</template>
