<template>
  <div>
    <va-alert color="info" class="mb-4">
      Alert with color style.
    </va-alert>
    <va-alert color="warning" outline class="mb-4">
      Alert with outline style.
    </va-alert>
    <va-alert color="danger" border="top" border-color="danger" class="mb-4">
      Alert with colorful border.
    </va-alert>
  </div>
</template>
