<template>
  <div>
    <va-alert center class="mb-4">
      You read this important centered alert message.
    </va-alert>
    <va-alert color="success" title="Title" center class="mb-4">
      You read this important centered alert message.
    </va-alert>
    <va-alert color="info" closeable title="Title" center class="mb-4">
      You read this important centered alert message.
    </va-alert>
    <va-alert color="danger" title="Title" icon="info" center class="mb-4">
      You read this important centered alert message.
    </va-alert>
    <va-alert color="warning" closeable title="Title" icon="info" center class="mb-4">
      You read this important centered alert message.
    </va-alert>
  </div>
</template>
