<template>
  <va-navbar color="primary" shape class="mb-2">
    <template #left>
      <va-navbar-item>LOGO HERE</va-navbar-item>
    </template>
    <template #center>
      <va-navbar-item>Primary</va-navbar-item>
    </template>
    <template #right>
      <va-navbar-item>Right</va-navbar-item>
    </template>
  </va-navbar>

  <va-navbar color="dark" shape class="mb-2">
    <template #left>
      <va-navbar-item>LOGO HERE</va-navbar-item>
    </template>
    <template #center>
      <va-navbar-item>Dark</va-navbar-item>
    </template>
    <template #right>
      <va-navbar-item>Right</va-navbar-item>
    </template>
  </va-navbar>
  <va-navbar color="#ff00ff" shape class="mb-2">
    <template #left>
      <va-navbar-item>LOGO HERE</va-navbar-item>
    </template>
    <template #center>
      <va-navbar-item>#ff00ff</va-navbar-item>
    </template>
    <template #right>
      <va-navbar-item>Right</va-navbar-item>
    </template>
  </va-navbar>
</template>
