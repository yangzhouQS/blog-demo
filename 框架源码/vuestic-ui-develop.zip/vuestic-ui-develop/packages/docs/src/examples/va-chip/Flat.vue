<template>
  <va-chip flat>
    flat chip
  </va-chip>
</template>
