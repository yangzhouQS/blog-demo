<template>
  <va-chip square>
    square
  </va-chip>
</template>
