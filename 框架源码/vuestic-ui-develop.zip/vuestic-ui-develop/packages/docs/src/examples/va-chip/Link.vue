<template>
  <va-chip to="/">Link chip</va-chip>
</template>
