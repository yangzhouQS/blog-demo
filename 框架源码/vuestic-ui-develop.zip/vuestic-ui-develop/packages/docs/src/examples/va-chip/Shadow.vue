<template>
  <va-chip shadow>Chip with shadow</va-chip>
</template>
