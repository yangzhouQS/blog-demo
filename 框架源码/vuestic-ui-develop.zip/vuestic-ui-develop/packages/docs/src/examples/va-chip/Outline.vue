<template>
  <va-chip outline>
    outline chip
  </va-chip>
</template>

<script>
export default {
  data () {
    return {
    }
  },
}
</script>
