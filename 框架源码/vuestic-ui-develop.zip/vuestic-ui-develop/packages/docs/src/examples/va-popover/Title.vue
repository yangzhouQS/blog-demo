<template>
  <va-popover
    title="Popover title"
    message="Popover text"
  >
    <va-button>Hover me</va-button>
  </va-popover>
</template>
