<template>
  <div>
    <va-popover
      class="mr-2 mb-2"
      message="Placement Bottom"
    >
      <va-button>Bottom</va-button>
    </va-popover>

    <va-popover
      class="mr-2 mb-2"
      placement="top"
      message="Placement Top"
    >
      <va-button>Top</va-button>
    </va-popover>

    <va-popover
      class="mr-2 mb-2"
      placement="left"
      message="Placement Left"
    >
      <va-button>Left</va-button>
    </va-popover>

    <va-popover
      placement="right"
      message="Placement Right"
    >
      <va-button>Right</va-button>
    </va-popover>
  </div>
</template>
