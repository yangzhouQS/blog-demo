<template>
  <va-popover
    icon="error"
    message="Popover with icon"
  >
    <va-button>Hover me</va-button>
  </va-popover>
</template>
