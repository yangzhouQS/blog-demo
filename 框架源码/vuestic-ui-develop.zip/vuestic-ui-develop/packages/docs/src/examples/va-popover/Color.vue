<template>
  <div>
    <va-popover
      class="mr-2 mb-2"
      message="Popover text"
      color="primary"
    >
      <va-button color="primary">
        Hover me
      </va-button>
    </va-popover>

    <va-popover
      class="mr-2 mb-2"
      message="Popover text"
      color="success"
    >
      <va-button color="success">
        Hover me
      </va-button>
    </va-popover>

    <va-popover
      class="mr-2 mb-2"
      message="Popover text"
      color="warning"
    >
      <va-button color="warning">
        Hover me
      </va-button>
    </va-popover>

    <va-popover
      class="mr-2 mb-2"
      message="Popover text"
      color="danger"
    >
      <va-button color="danger">
        Hover me
      </va-button>
    </va-popover>

    <va-popover
      message="Popover text"
      color="#9f03e0"
    >
      <va-button color="#9f03e0">
        Hover me
      </va-button>
    </va-popover>
  </div>
</template>
