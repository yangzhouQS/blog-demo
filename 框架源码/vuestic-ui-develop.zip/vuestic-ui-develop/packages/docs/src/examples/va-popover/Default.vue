<template>
  <va-popover
    message="Popover text"
  >
    <va-button>Hover me</va-button>
  </va-popover>
</template>
