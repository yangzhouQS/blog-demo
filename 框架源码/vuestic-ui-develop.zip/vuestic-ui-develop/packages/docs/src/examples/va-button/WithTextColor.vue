<template>
  <va-button text-color="#000000" class="mr-4">Black text</va-button>
  <va-button outline text-color="#ff1100" class="mr-4">Red text</va-button>
  <va-button :rounded="false" text-color="#09ff00" class="mr-4">Green text</va-button>
</template>
