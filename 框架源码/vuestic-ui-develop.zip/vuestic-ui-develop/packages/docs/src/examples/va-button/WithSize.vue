<template>
  <div>
    <va-button size="small" class="mr-4">Small</va-button>
    <va-button size="medium" class="mr-4">Medium</va-button>
    <va-button size="large" class="mr-4">Large</va-button>
  </div>
</template>
