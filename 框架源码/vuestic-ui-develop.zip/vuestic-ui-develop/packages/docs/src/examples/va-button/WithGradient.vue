<template>
  <div>
    <va-button color="info" gradient class="mr-4">Info</va-button>
    <va-button color="danger" gradient class="mr-4">Danger</va-button>
    <va-button color="warning" gradient>Warning</va-button>
  </div>
</template>
