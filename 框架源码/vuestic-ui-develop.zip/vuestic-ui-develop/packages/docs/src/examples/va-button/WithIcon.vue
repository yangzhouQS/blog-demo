<template>
  <div>
    <va-button icon="clear" class="mr-4">Clear</va-button>
    <va-button icon-right="create" class="mr-4">Edit</va-button>
    <va-button icon="block" />
  </div>
</template>
