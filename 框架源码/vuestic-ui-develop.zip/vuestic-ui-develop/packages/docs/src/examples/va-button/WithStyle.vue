<template>
  <div>
    <va-button outline class="mr-4">Outline</va-button>
    <va-button flat class="mr-4">Flat</va-button>
    <va-button :rounded="false" class="mr-4">Square</va-button>
  </div>
</template>
