<template>
  <va-breadcrumbs color="primary">
    <va-breadcrumbs-item label="One" />
    <va-breadcrumbs-item label="Two" />
    <va-breadcrumbs-item label="Three" />
  </va-breadcrumbs>
</template>
