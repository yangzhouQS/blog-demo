<template>
  <va-breadcrumbs align="right">
    <va-breadcrumbs-item label="One" />
    <va-breadcrumbs-item label="Two" />
    <va-breadcrumbs-item label="Three" />
  </va-breadcrumbs>
</template>
