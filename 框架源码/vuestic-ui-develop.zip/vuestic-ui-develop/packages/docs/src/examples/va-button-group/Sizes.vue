<template>
  <div>
    <va-button-group class="mb-4">
      <va-button size="large">
        One
      </va-button>
      <va-button size="large">
        Two
      </va-button>
      <va-button size="large">
        Three
      </va-button>
    </va-button-group>

    <va-button-group class="mb-4">
      <va-button size="small">
        One
      </va-button>
      <va-button size="small">
        Two
      </va-button>
      <va-button size="small">
        Three
      </va-button>
    </va-button-group>
  </div>
</template>
