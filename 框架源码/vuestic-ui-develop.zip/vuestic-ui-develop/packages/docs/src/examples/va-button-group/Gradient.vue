<template>
  <div>
    <va-button-group gradient color="danger" class="mb-4">
      <va-button>One</va-button>
      <va-button>Two</va-button>
      <va-button>Three</va-button>
    </va-button-group>

    <va-button-group gradient color="warning" class="mb-4">
      <va-button>One</va-button>
      <va-button>Two</va-button>
      <va-button>Three</va-button>
    </va-button-group>

    <va-button-group gradient color="success" class="mb-4">
      <va-button>One</va-button>
      <va-button>Two</va-button>
      <va-button>Three</va-button>
    </va-button-group>
  </div>
</template>
