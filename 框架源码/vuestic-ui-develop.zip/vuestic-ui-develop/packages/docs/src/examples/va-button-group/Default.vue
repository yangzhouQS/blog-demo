<template>
  <va-button-group>
    <va-button> Button 1</va-button>
    <va-button> Button 2</va-button>
    <va-button> Button 3</va-button>
  </va-button-group>
</template>
