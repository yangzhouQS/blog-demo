<template>
  <va-button-group>
    <va-button icon="create" />
    <va-button icon="add" />
    <va-button icon="add_circle_outline" />
  </va-button-group>
</template>
