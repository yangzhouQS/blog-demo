<template>
  <div>
    <va-button-group color="danger" class="mb-4">
      <va-button>One</va-button>
      <va-button>Two</va-button>
      <va-button>Three</va-button>
    </va-button-group>

    <va-button-group color="warning" class="mb-4">
      <va-button>One</va-button>
      <va-button>Two</va-button>
      <va-button>Three</va-button>
    </va-button-group>

    <va-button-group color="success" class="mb-4">
      <va-button>One</va-button>
      <va-button>Two</va-button>
      <va-button>Three</va-button>
    </va-button-group>
  </div>
</template>
