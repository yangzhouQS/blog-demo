<template>
  <va-avatar src="https://randomuser.me/api/portraits/women/5.jpg" />
</template>
