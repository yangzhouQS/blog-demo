<template>
  <va-avatar>
    <va-icon name="warning" />
  </va-avatar>
</template>
