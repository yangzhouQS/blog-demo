<template>
  <div title="сolor">
    <va-avatar color="danger" class="mr-4">
      Z
    </va-avatar>
    <va-avatar text-color="danger" class="mr-4">
      Z
    </va-avatar>
  </div>
</template>
