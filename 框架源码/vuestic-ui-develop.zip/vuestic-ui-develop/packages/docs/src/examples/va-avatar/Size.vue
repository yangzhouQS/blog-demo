<template>
  <div>
    <va-avatar size="small" class="mr-4">S</va-avatar>
    <va-avatar class="mr-4">S</va-avatar>
    <va-avatar size="large" font-size="30px" class="mr-4">S</va-avatar>
  </div>
</template>
