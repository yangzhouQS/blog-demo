<template>
  <va-avatar icon="info_outline" />
</template>
