<template>
  <va-parallax
    target=".base-layout__content"
    :src="imageSrc"
  >
    {{ lorem }}
  </va-parallax>
</template>

<script>
export default {
  data () {
    return {
      imageSrc: 'https://images.wallpaperscraft.com/image/beach_ocean_silhouette_141758_1280x800.jpg',
      lorem: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, sapiente provident commodi beatae reiciendis, iste quae ipsam laboriosam odio eum voluptatum vero sit non distinctio temporibus deleniti aliquid error? Nulla, iure. Est officia, fuga laudantium accusamus reprehenderit, facere unde corrupti possimus et tenetur nulla iure incidunt saepe beatae, deleniti culpa vero sapiente perferendis non? Temporibus veritatis eligendi quasi magni aliquid non cumque sunt consequatur illum, et dolorum esse ullam assumenda repellendus iste nobis quos maxime quia corporis eaque nisi voluptate dignissimos voluptatem. Quasi illo reiciendis sint magni quos eaque mollitia optio, odit, voluptates amet consequatur. Dolor debitis, in fugit iste nemo saepe doloribus ea ratione possimus. Error incidunt laboriosam modi quae qui aperiam veniam voluptatibus commodi vel fugit expedita laudantium, obcaecati fugiat dicta quas atque. Adipisci voluptatibus amet sed quibusdam itaque cupiditate magni nemo? Tempora eum a laboriosam, rerum sequi minima facere hic porro asperiores laborum doloribus, quas dolorum, nesciunt maiores velit voluptate eos. Ea debitis autem tempore quisquam impedit eveniet, blanditiis, ut repellendus labore totam ad quod est! Minima veniam eligendi debitis non rem esse repellat officia neque aspernatur dicta, enim soluta minus necessitatibus quod sequi maiores nesciunt eos. Repellat cum repudiandae distinctio ullam placeat dicta reprehenderit alias aut reiciendis aliquam, vitae, ipsa voluptatem repellendus esse aliquid sit laudantium doloremque qui obcaecati. Praesentium esse quos reiciendis ut doloribus necessitatibus nam culpa natus, incidunt voluptatum. Distinctio accusamus architecto veritatis sequi inventore rerum, eaque quod! Similique facilis, tenetur maiores, omnis vitae repudiandae hic quo sunt ut quam minima reiciendis voluptate, modi magni natus rerum sapiente voluptates fugiat animi laboriosam deserunt! Dolor dolorem ab facilis hic? Excepturi quo, eum consequuntur velit repellat voluptatibus facere voluptatum debitis quas',
    }
  },
}
</script>
