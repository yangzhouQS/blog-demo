<template>
  <div class="my-5">
    <va-divider />
  </div>
</template>
