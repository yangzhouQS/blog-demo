<template>
  <div class="row my-5">
    <span class="flex lg1">Title</span>
    <va-divider vertical />
    <span class="flex lg1">News</span>
    <va-divider vertical />
    <span class="flex lg1">Blog</span>
  </div>
</template>
