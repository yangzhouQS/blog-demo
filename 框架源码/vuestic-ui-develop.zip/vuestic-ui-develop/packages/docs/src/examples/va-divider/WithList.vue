<template>
  <div class="my-5 flex lg4 xs12">
    <va-list>
      <va-list-item>
        <span class="ml-4">I'm a list item</span>
      </va-list-item>
      <va-divider>Default</va-divider>
      <va-list-item>
        <span class="ml-4">I'm a list item</span>
      </va-list-item>
      <va-divider />
      <va-list-item>
        <span class="ml-4">I'm a list item</span>
      </va-list-item>
      <va-divider inset>
        Inset
      </va-divider>
      <va-list-item>
        <span class="ml-4">I'm a list item</span>
      </va-list-item>
      <va-divider inset />
      <va-list-item>
        <span class="ml-4">I'm a list item</span>
      </va-list-item>
    </va-list>
  </div>
</template>
