<template>
  <va-button outline :rounded="false" size="small">
    Your button
  </va-button>
</template>
