<template>
  <va-color-input v-model="value" disabled />
</template>

<script>
export default {
  data () {
    return {
      value: '#FF00FF',
    }
  },
}
</script>
