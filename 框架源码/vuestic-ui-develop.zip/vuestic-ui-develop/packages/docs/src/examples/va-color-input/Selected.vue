<template>
  <va-color-input v-model="value" selected />
</template>

<script>
export default {
  data () {
    return {
      value: '#FF00FF',
    }
  },
}
</script>
