<template>
  <va-sidebar-item>
    <va-sidebar-item-content>
      <va-sidebar-item-title>
        Home
      </va-sidebar-item-title>
    </va-sidebar-item-content>
  </va-sidebar-item>

  <va-sidebar-item>
    <va-sidebar-item-content>
      <va-sidebar-item-title style="text-align: center;">I'm centered!</va-sidebar-item-title>
    </va-sidebar-item-content>
  </va-sidebar-item>

  <va-sidebar-item active>
    <va-sidebar-item-content>
      <va-sidebar-item-title>
        Docs (active)
      </va-sidebar-item-title>
    </va-sidebar-item-content>
  </va-sidebar-item>
</template>
