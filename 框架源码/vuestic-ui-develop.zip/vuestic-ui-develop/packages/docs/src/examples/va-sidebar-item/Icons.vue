<template>
  <va-sidebar-item>
    <va-sidebar-item-content>
      <va-sidebar-item-title>
        Home
      </va-sidebar-item-title>
      <va-icon name="home" />
    </va-sidebar-item-content>
  </va-sidebar-item>

  <va-sidebar-item active>
    <va-sidebar-item-content>
      <va-sidebar-item-title>
        Docs
      </va-sidebar-item-title>
      <va-icon name="article" />
    </va-sidebar-item-content>
  </va-sidebar-item>

  <va-sidebar-item>
    <va-sidebar-item-content>
      <va-icon name="cake" />
      <va-icon name="celebration" />
      <va-sidebar-item-title style="text-align: center;">GO TO PARTY!</va-sidebar-item-title>
      <va-icon name="cake" />
      <va-icon name="celebration" />
    </va-sidebar-item-content>
  </va-sidebar-item>

  <va-sidebar-item>
    <va-sidebar-item-content>
      <va-sidebar-item-title>
        Something cool
      </va-sidebar-item-title>
      <va-chip>New!</va-chip>
    </va-sidebar-item-content>
  </va-sidebar-item>
</template>
