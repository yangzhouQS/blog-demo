<template>
  <va-sidebar-item hover-color="success">
    <va-sidebar-item-content>
      <va-sidebar-item-title>
        Success hover color
      </va-sidebar-item-title>
    </va-sidebar-item-content>
  </va-sidebar-item>

  <va-sidebar-item text-color="danger">
    <va-sidebar-item-content>
      <va-sidebar-item-title>Danger text color</va-sidebar-item-title>
    </va-sidebar-item-content>
  </va-sidebar-item>

  <va-sidebar-item active active-color="warning">
    <va-sidebar-item-content>
      <va-sidebar-item-title>
        Warning active color (active)
      </va-sidebar-item-title>
    </va-sidebar-item-content>
  </va-sidebar-item>
</template>
