<template>
  <div class="flex lg6 xs12">
    <va-progress-circle
      :modelValue="65"
      color="danger"
    />
    <br />
    <va-progress-circle
      :modelValue="65"
      color="purple"
    />
  </div>
</template>
