<template>
  <div class="flex lg6 xs12 py-4">
    <va-progress-circle indeterminate />
  </div>
</template>
