<template>
  <va-color-slider v-model="value" />
</template>

<script>
export default {
  data () {
    return {
      value: '#FF00FF',
    }
  },
}
</script>
