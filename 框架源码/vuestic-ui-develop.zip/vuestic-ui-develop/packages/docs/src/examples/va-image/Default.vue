<template>
  <div class="row">
    <div class="flex md6 lg4">
      <va-image src="https://picsum.photos/1500" />
    </div>
  </div>
</template>
