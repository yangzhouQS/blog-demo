<template>
  <div class="row">
    <div class="flex md6 lg4">
      <va-image src="https://picsum.photos/1500/500" />
    </div>
    <div class="flex md6 lg4">
      <va-image contain src="https://picsum.photos/1500/500" />
    </div>
  </div>
</template>
