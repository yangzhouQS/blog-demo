<template>
  <div class="row">
    <div class="flex md6 lg4">
      <va-image ratio="0.75" src="https://picsum.photos/1500" />
    </div>
    <div class="flex md6 lg4">
      <va-image :ratio="4/3" src="https://picsum.photos/1500" />
    </div>
  </div>
</template>
