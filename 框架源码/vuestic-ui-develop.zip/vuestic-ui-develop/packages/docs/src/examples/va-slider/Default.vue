<template>
  <div>
    <va-slider v-model="value" />
  </div>
</template>

<script>
export default {
  data () {
    return {
      value: 45,
    }
  },
}
</script>
