<template>
  <div class="flex lg6 xs12">
    <va-progress-bar
      model-value="35"
      color="danger"
    />
    <br />
    <va-progress-bar
      model-value="35"
      color="purple"
    />
  </div>
</template>
