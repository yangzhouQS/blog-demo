<template>
  <va-card color="background" style="padding: 0.75rem;">
    <div class="row">
      <div class="flex md12">
        <div class="item">md12</div>
      </div>
      <div class="flex md6">
        <div class="item">md6</div>
      </div>
      <div class="flex md6">
        <div class="item">md6</div>
      </div>
    </div>
    <br />
    <div class="row">
      <div class="flex md12">
        <div class="item">md12</div>
      </div>
      <div class="flex md9">
        <div class="item">md9</div>
      </div>
      <div class="flex md3">
        <div class="item">md3</div>
      </div>
    </div>
  </va-card>
</template>

<style lang="scss" scoped>
.item {
  border: 1px solid rgb(212, 205, 205);
  background-color: #ffffff;
  text-align: center;
}
</style>
