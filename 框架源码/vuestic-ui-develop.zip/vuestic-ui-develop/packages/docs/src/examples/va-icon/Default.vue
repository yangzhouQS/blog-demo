<template>
  <div>
      <p>Material Design</p>
      <va-icon class="material-icons">home</va-icon>
      <va-icon name="home" class="ml-4" />

      <p>Font Awesome 4</p>
      <va-icon class="fa fa-home" />
      <va-icon name="fa4-home" class="ml-4" />

      <p>Font Awesome 5</p>
      <va-icon class="fas fa-home" />
      <va-icon name="fas-home" class="ml-4" />

      <p>Entypo</p>
      <va-icon class="entypo-home" />
      <va-icon name="entypo-home" class="ml-4" />

      <p>Ionic</p>
      <va-icon class="icon ion-md-home" />
      <va-icon name="ion-home" class="ml-4" />
  </div>
</template>
