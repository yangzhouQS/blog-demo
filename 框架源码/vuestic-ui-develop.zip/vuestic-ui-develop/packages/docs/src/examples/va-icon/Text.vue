<template>
  <div>
    <va-icon class="mr-2">close</va-icon>
    <va-icon class="mr-2">&#10032;</va-icon>
  </div>
</template>
