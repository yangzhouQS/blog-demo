<template>
  <div>
    <va-affix :offset-top="100">
      <div style="padding: 10px 30px; background-color: lightblue;">
        Fixed at the top: 100
      </div>
    </va-affix>
  </div>
</template>
