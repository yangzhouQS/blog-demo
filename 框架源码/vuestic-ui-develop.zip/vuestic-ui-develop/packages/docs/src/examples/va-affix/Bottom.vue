<template>
  <div>
    <va-affix :offset-bottom="50">
      <div style="padding: 10px 30px; background-color: lightblue;">
        Fixed at the bottom: 50
      </div>
    </va-affix>
  </div>
</template>
