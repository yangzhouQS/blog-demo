<template>
  <va-color-picker v-model="value" />
</template>

<script>
export default {
  data () {
    return {
      value: '#9C4040',
    }
  },
}
</script>
