<template>
  <va-rating v-model="value" />
</template>
<script>
export default {
  data () {
    return {
      value: 3,
    }
  },
}
</script>
