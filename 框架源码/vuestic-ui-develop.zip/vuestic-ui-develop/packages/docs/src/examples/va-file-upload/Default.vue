<template>
  <va-file-upload v-model="basic" />
</template>

<script>
export default {
  data () {
    return {
      basic: [],
    }
  },
}
</script>
