<template>
  <va-file-upload v-model="basic" dropzone />
</template>

<script>
export default {
  data () {
    return {
      basic: [],
    }
  },
}
</script>
