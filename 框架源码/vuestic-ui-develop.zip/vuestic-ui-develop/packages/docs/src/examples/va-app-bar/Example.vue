<template>
  <va-app-bar />
</template>

<script>
export default {
  data () {
    return {

    }
  },
}
</script>
