<template>
  <va-button-dropdown
    split
    label="Split"
  >
    Content
  </va-button-dropdown>
</template>
