<template>
  <div>
    <va-button-dropdown
      class="mr-2 mb-2"
      color="warning"
      label="warning"
    >
      Content
    </va-button-dropdown>
    <va-button-dropdown
      class="mr-2 mb-2"
      color="danger"
      label="danger"
    >
      Content
    </va-button-dropdown>
    <va-button-dropdown
      color="info"
      label="info"
    >
      Content
    </va-button-dropdown>
  </div>
</template>
