<template>
  <div>
    <va-button-dropdown
      class="mr-2 mb-2"
      size="small"
      label="small"
    >
      Content
    </va-button-dropdown>
    <va-button-dropdown
      size="large"
      label="large"
    >
      Content
    </va-button-dropdown>
  </div>
</template>
