<template>
  <div>
    <va-button-dropdown
      class="mr-2 mb-2"
      disabled
      label="disabled"
    >
      Content
    </va-button-dropdown>
    <va-button-dropdown
      class="mr-2 mb-2"
      split
      disable-button
      label="disable-button"
    >
      Content
    </va-button-dropdown>
    <va-button-dropdown
      split
      disable-dropdown
      label="disable-dropdown"
    >
      Content
    </va-button-dropdown>
  </div>
</template>
