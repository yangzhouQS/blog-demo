<template>
  <va-button-dropdown
    class="mr-2 mb-2"
    label="Will not close dropdown on click"
    :close-on-content-click="false"
  >
    Content
  </va-button-dropdown>
</template>
