<template>
  <div>
    <va-button-dropdown
      class="mr-2 mb-2"
      outline
      label="outline"
    >
      Content
    </va-button-dropdown>
    <va-button-dropdown
      class="mr-2 mb-2"
      flat
      label="flat"
    >
      Content
    </va-button-dropdown>
  </div>
</template>
