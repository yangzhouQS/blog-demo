import { GlobalConfig } from 'vuestic-ui/src/main'
import { icons } from './icons-config/icons-config'

export const VuesticConfig: GlobalConfig = {
  icons,
}
