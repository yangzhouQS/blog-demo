import { createIconsConfig } from 'vuestic-ui/src/main'
import { aliases } from './aliases'
import { fonts } from './fonts'

export const icons = createIconsConfig({ aliases, fonts })
