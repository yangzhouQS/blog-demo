<template>
  <svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M4.5 16.1272C3.86093 14.891 3.5 13.4876 3.5 12C3.5 7.02944 7.52944 3 12.5 3C14.3401 3 16.0512 3.55223 17.4767 4.5M7.5 19.4845C8.9301 20.4417 10.6499 21 12.5 21C17.4706 21 21.5 16.9706 21.5 12C21.5 10.3607 21.0617 8.82378 20.296 7.5" :stroke="colors.primary" stroke-width="2" />
    <path d="M4.5 16.1272C3.86093 14.891 3.5 13.4876 3.5 12C3.5 7.02944 7.52944 3 12.5 3C14.3401 3 16.0512 3.55223 17.4767 4.5M7.5 19.4845C8.9301 20.4417 10.6499 21 12.5 21C17.4706 21 21.5 16.9706 21.5 12C21.5 10.3607 21.0617 8.82378 20.296 7.5" :stroke="colors.primary" stroke-width="2" />
    <circle cx="5.5" cy="18" r="2" :stroke="colors.primary" stroke-width="2" />
    <circle cx="19.5" cy="6" r="2" :stroke="colors.primary" stroke-width="2" />
    <circle cx="12.5" cy="12" r="4" :stroke="colors.primary" stroke-width="2" />
  </svg>
</template>

<script>
import { getColors } from 'vuestic-ui/src/services/color-config/color-config'

export default {
  name: 'IconSpinners',
  computed: {
    colors () {
      return getColors()
    },
  },
}
</script>
