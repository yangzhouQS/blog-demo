// @ts-ignore
import { ManualApiOptions } from 'vuestic-ui/src/services/api-docs/ManualApiOptions'

export default {
  props: {
  },
  events: {
  },
  methods: {
  },
  slots: {
    default: { local: true },
  },
} as ManualApiOptions
