import { DocsHelper } from '../../../../../helpers/DocsHelper'

export default DocsHelper.exampleBlock(
  'sidebarItem.examples.components.title',
  'sidebarItem.examples.components.text',
  'va-sidebar-item/Components',
)
