import { ManualApiOptions } from 'vuestic-ui/src/services/api-docs/ManualApiOptions'

export default {
  props: {
    shape: {
      local: true,
    },
  },
  events: {
  },
  methods: {
  },
  slots: {
  },
} as ManualApiOptions
