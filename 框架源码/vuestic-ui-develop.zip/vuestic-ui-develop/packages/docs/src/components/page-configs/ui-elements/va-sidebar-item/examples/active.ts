import { DocsHelper } from '../../../../../helpers/DocsHelper'

export default DocsHelper.exampleBlock(
  'sidebarItem.examples.active.title',
  'sidebarItem.examples.active.text',
  'va-sidebar-item/Active',
)
