import { DocsHelper } from '../../../../../helpers/DocsHelper'

export default DocsHelper.exampleBlock(
  'sidebarItem.examples.icons.title',
  'sidebarItem.examples.icons.text',
  'va-sidebar-item/Icons',
)
