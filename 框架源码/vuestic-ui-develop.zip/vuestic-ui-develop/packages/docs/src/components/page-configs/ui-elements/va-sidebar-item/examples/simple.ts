import { DocsHelper } from '../../../../../helpers/DocsHelper'

export default DocsHelper.exampleBlock(
  'sidebarItem.examples.simple.title',
  'sidebarItem.examples.simple.text',
  'va-sidebar-item/Simple',
)
