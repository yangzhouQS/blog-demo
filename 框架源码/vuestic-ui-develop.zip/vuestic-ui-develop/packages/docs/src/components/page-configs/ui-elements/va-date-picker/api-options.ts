// @ts-ignore
import { ManualApiOptions } from 'vuestic-ui/src/services/api-docs/ManualApiOptions'

export default {
  props: {
    value: { local: true },
    weekDays: { local: true },
    placeholder: { local: true },
    config: { local: true },
  },
  events: {
  },
  methods: {
  },
  slots: {
  },
} as ManualApiOptions
