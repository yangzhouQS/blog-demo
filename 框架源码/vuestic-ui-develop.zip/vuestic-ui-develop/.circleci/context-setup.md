# Context setup example for circleci

* `SERVER_IP` 12.34.56.789
* `SERVER_USER` root
* `DEPLOY_PATH` /var/www/html/your-site
