---
name: Bug Report
about: Bug Report
title: ''
labels: bug
assignees: ''

---

* **What is the expected behavior?**

* **What is the current behavior?**

* **Steps to reproduce, ideally also a screenshot or gif if it's a style issue**

* **Other information** <!-- (e.g. detailed explanation, stacktraces, related issues, suggestions how to fix, links for us to have context, eg. stackoverflow, gitter, etc) -->
