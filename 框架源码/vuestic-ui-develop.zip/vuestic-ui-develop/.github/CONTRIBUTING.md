# Vue.js Contributing Guide

Check contribution docs [here](http://localhost:8080/en/contribution/guide).
