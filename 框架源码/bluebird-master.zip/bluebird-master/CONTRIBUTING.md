
# Questions and issues

Please see [The Support Page](http://bluebirdjs.com/docs/support.html)
The [github issue tracker](https://github.com/petkaantonov/bluebird/issues) is **_only_** for bug reports and feature requests.

# Contributing to the library

Contributions are welcome and appreciated. See the [Contribution Page](http://bluebirdjs.com/docs/contribute.html) on bluebirdjs.com
