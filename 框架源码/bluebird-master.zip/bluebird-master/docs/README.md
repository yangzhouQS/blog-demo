Requires ruby and [jekyll](http://jekyllrb.com/). See the gem file for dependencies.

Change directory to `bluebird/docs` and run `jekyll serve`. The docs will be hosted under `/docs` directory in relation to the web root. Typically something like `http://localhost:4000/docs/`


