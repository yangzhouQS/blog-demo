---
id: what-about-generators
title: What About Generators?
---

There is an [excellent article](https://www.promisejs.org/generators/) on promisejs.org detailing how to combine promises with generators to achieve much cleaner code. Instead of the `async` function the article proposes, you can use [Promise.coroutine](.).

[what-about-generators](unfinished-article)
