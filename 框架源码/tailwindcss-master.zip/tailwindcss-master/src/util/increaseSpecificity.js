export default function(importantVal, selector) {
  return `${importantVal} ${selector}`
}
