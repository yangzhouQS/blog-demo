import createUtilityPlugin from '../util/createUtilityPlugin'

export default function() {
  return createUtilityPlugin('transitionTimingFunction', [['ease', ['transitionTimingFunction']]])
}
