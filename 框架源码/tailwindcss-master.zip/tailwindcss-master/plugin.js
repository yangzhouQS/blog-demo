const createPlugin = require('./lib/util/createPlugin').default

module.exports = createPlugin
