<template>
    <span class="cell">{{ params.value }}</span>
</template>

<script>
export default {
};
</script>

<style scoped>
.cell {
    color: blue;
}
</style>
