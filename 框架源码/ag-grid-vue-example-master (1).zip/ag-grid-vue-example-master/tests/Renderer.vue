<template>
    <span>{{this.params.value * 2}}</span>
</template>

<script>
</script>

<style scoped>
</style>


