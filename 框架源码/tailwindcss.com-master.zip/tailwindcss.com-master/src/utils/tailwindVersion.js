// @preval
module.exports.tailwindVersion = require('tailwindcss/package.json').version
