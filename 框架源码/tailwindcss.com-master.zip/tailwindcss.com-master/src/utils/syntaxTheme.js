module.exports = {
  punctuation: 'text-code-punctuation',
  tag: 'text-code-tag',
  'attr-name': 'text-code-attr-name',
  'attr-value': 'text-code-attr-value',
  class: 'text-code-attr-value',
  string: 'text-code-string',
  comment: 'opacity-25',
}
