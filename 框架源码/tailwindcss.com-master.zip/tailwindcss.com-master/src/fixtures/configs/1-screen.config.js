module.exports = {
  purge: false,
  theme: {
    screens: {
      sm: '640px',
    },
  },
  variants: {},
  plugins: [],
}
