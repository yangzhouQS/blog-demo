module.exports = {
  purge: false,
  theme: {
    screens: {
      sm: '640px',
      md: '768px',
    },
  },
  variants: {},
  plugins: [],
}
