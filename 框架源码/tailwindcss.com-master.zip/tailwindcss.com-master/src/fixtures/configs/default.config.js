module.exports = {
  purge: false,
  theme: {},
  variants: {},
  plugins: [],
}
