module.exports = {
  plugins: ['tailwindcss', 'postcss-nested', 'postcss-focus-visible', 'autoprefixer'],
}
