---
name: Suggestion
about: 为这个项目提出一个建议
title: '[suggest]'
labels: 'help wanted'
assignees: ''

---

## 你建议我们做什么？

<!--对你想要发生的事情的清晰而简洁的描述-->
现在...

如果你能...

它将使...

## 其它

无