import { shallowMount } from '@vue/test-utils'
import Radio from '../radio.vue';
import Vue from 'vue';
