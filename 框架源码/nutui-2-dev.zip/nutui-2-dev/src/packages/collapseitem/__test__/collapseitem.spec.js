import { shallowMount, mount } from '@vue/test-utils';
import CollapseItem from '../collapseitem.vue';
import Vue from 'vue';

describe('CollapseItem.vue', () => {});
