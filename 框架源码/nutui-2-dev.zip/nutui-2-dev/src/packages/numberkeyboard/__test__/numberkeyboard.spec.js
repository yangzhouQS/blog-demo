import { shallowMount, mount } from '@vue/test-utils';
import NumberKeyboard from '../numberkeyboard.vue';
import Vue from 'vue';

describe('NumberKeyboard.vue', () => {});
