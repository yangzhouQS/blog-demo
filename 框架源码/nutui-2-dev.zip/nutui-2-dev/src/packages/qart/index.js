import VueQr from 'vue-qr';
VueQr.name = 'vue-qr';
export default VueQr;
