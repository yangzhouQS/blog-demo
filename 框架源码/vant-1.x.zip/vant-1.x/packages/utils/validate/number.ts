export function isNumber(value: string): boolean {
  return /^\d+$/.test(value);
}
