import Demo from '../demo';
import demoTest from '../../../test/demo-test';

demoTest(Demo);
