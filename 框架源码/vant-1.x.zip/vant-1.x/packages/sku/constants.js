export const LIMIT_TYPE = {
  QUOTA_LIMIT: 0,
  STOCK_LIMIT: 1
};

export const UNSELECTED_SKU_VALUE_ID = '';

export default {
  LIMIT_TYPE,
  UNSELECTED_SKU_VALUE_ID
};
