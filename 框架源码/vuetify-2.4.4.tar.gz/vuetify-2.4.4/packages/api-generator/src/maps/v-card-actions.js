module.exports = {
  'v-card-actions': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
