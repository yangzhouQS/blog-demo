module.exports = {
  'v-avatar': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
