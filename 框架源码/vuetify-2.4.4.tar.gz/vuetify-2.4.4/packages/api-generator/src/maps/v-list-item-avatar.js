module.exports = {
  'v-list-item-avatar': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
