module.exports = {
  'v-badge': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
      {
        name: 'badge',
        props: undefined,
      },
    ],
  },
}
