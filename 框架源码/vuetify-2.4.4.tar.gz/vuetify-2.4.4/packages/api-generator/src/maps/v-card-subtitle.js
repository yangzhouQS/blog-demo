module.exports = {
  'v-card-subtitle': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
