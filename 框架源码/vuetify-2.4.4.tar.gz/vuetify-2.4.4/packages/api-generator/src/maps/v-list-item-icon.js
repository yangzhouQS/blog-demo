module.exports = {
  'v-list-item-icon': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
