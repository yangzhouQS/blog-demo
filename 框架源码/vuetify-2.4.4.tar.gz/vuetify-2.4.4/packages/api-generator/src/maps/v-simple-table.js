module.exports = {
  'v-simple-table': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
