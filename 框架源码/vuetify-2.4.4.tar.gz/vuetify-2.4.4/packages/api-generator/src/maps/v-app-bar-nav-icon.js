module.exports = {
  'v-app-bar-nav-icon': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
