module.exports = {
  'v-card-text': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
