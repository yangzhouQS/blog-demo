const { VTextField } = require('../helpers/variables')

module.exports = {
  'v-textarea': VTextField,
}
