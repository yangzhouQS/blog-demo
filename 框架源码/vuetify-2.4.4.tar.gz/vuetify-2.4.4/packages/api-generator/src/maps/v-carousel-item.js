module.exports = {
  'v-carousel-item': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
