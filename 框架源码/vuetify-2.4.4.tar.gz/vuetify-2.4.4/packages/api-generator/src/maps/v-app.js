module.exports = {
  'v-app': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
