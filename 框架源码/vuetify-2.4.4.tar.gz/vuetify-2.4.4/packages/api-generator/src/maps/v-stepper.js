module.exports = {
  'v-stepper': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
    events: [
      {
        name: 'change',
        value: 'number',
      },
    ],
  },
}
