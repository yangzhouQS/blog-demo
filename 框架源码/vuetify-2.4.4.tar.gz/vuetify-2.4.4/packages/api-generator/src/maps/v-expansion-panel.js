module.exports = {
  'v-expansion-panel': {
    events: [
      {
        name: 'change',
        value: 'void',
      },
      {
        name: 'click',
        value: 'MouseEvent',
      },
    ],
  },
}
