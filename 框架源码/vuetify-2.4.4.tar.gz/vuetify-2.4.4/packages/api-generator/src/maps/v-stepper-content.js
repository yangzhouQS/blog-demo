module.exports = {
  'v-stepper-content': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
