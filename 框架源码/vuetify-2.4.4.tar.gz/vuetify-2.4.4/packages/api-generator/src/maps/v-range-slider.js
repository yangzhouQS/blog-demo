const { VRangeSlider } = require('../helpers/variables')

module.exports = {
  'v-range-slider': VRangeSlider,
}
