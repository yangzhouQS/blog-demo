module.exports = {
  'v-item-group': {
    events: [
      {
        name: 'change',
        value: 'any[] | any',
      },
    ],
  },
}
