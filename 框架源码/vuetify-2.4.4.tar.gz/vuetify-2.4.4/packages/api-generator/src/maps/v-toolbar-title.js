module.exports = {
  'v-toolbar-title': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
