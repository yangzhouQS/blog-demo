module.exports = {
  'v-chip-group': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
    events: [
      {
        name: 'change',
        value: 'any[] | any',
      },
    ],
  },
}
