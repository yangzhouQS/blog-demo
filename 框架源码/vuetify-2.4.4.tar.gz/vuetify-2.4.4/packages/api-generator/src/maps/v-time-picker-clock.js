module.exports = {
  'v-time-picker-clock': {
    props: [
      {
        name: 'format',
        default: '(val: string): string',
      },
    ],
  },
}
