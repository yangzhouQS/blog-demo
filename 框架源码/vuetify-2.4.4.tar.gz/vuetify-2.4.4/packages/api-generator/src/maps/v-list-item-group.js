module.exports = {
  'v-list-item-group': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
    events: [
      {
        name: 'change',
        value: 'any[] | any',
      },
    ],
  },
}
