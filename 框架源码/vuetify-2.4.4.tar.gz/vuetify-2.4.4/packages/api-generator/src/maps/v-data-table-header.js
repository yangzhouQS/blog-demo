module.exports = {
  'v-data-table-header': {
    props: [
      {
        name: 'sortByText',
        default: `'Sort by'`,
        source: 'v-data-table-header',
        type: 'string',
      },
    ],
  },
}
