const { VInput } = require('../helpers/variables')

module.exports = {
  'v-input': VInput,
}
