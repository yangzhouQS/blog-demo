module.exports = {
  'v-list-item-subtitle': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
