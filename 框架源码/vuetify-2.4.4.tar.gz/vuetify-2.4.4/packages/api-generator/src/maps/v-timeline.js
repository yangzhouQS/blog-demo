module.exports = {
  'v-timeline': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
