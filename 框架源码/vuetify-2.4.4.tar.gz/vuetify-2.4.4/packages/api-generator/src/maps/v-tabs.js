module.exports = {
  'v-tabs': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
    events: [
      {
        name: 'change',
        value: 'number',
      },
    ],
  },
}
