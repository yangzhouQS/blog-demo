module.exports = {
  'v-stepper-items': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
