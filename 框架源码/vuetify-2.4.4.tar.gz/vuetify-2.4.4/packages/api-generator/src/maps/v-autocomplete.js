const { VAutocomplete } = require('../helpers/variables')

module.exports = {
  'v-autocomplete': VAutocomplete,
}
