module.exports = {
  'v-window-item': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
