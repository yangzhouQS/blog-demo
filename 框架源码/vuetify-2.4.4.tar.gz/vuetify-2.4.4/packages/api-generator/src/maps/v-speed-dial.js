module.exports = {
  'v-speed-dial': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
      {
        name: 'activator',
        props: undefined,
      },
    ],
  },
}
