module.exports = {
  'v-list-item-title': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
