module.exports = {
  'v-list-item-content': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
