module.exports = {
  'v-virtual-scroll': {
    slots: [
      {
        name: 'default',
        props: {
          index: 'number',
          item: 'any',
        },
      },
    ],
  },
}
