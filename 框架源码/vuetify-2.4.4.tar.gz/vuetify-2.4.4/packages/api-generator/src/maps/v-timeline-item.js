module.exports = {
  'v-timeline-item': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
      {
        name: 'icon',
        props: undefined,
      },
      {
        name: 'opposite',
        props: undefined,
      },
    ],
  },
}
