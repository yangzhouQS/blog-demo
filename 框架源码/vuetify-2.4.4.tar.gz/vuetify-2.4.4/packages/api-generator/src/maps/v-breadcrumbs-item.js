module.exports = {
  'v-breadcrumbs-item': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
