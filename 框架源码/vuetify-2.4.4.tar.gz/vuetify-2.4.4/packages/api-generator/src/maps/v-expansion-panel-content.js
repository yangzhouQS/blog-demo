module.exports = {
  'v-expansion-panel-content': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
