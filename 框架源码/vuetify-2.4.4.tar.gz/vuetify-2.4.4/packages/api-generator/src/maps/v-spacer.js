module.exports = {
  'v-spacer': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
