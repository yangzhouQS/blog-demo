module.exports = {
  'v-slide-item': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
