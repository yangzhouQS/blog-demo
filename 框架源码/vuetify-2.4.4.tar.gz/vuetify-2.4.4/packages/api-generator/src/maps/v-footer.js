module.exports = {
  'v-footer': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
