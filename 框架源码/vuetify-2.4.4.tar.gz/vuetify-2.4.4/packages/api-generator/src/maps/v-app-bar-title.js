module.exports = {
  'v-app-bar-title': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
