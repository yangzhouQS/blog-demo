module.exports = {
  'v-btn-toggle': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
    events: [
      {
        name: 'change',
        value: 'any[] | any',
      },
    ],
  },
}
