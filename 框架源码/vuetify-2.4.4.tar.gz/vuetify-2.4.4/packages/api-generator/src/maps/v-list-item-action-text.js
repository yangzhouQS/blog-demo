module.exports = {
  'v-list-item-action-text': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
