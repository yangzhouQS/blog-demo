module.exports = {
  'v-subheader': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
