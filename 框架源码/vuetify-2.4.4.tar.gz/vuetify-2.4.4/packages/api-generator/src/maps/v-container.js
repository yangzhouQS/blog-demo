module.exports = {
  'v-container': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
