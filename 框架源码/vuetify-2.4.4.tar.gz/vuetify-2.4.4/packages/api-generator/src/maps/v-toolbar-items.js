module.exports = {
  'v-toolbar-items': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
