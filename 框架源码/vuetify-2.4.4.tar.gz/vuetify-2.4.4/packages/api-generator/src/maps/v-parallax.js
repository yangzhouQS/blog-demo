module.exports = {
  'v-parallax': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
