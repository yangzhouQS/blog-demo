module.exports = {
  'v-col': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
