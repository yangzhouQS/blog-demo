module.exports = {
  'v-lazy': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
