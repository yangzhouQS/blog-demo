module.exports = {
  'v-card-title': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
