module.exports = {
  'v-overlay': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
