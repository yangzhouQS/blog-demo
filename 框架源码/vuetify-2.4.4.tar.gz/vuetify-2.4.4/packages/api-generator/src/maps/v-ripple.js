module.exports = {
  'v-ripple': {
    argument: [{
      name: 'argument',
      type: ['object'],
      default: undefined,
      example: {
        center: 'boolean',
        class: 'string',
      },
    }],
  },
}
