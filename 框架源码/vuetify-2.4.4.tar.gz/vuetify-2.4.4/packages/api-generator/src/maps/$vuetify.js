module.exports = {
  $vuetify: {
    functions: [
      {
        name: 'goTo',
        signature: '() => void',
      },
    ],
  },
}
