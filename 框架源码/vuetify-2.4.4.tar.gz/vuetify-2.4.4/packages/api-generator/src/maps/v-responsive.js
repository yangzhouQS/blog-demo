module.exports = {
  'v-responsive': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
