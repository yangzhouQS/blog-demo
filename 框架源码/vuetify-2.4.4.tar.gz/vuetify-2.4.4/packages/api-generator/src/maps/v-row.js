module.exports = {
  'v-row': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
