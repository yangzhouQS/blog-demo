module.exports = {
  'v-list': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
