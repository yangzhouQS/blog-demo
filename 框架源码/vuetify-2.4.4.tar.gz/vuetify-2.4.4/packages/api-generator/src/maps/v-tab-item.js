module.exports = {
  'v-tab-item': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
