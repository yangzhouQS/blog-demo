module.exports = {
  'v-tabs-items': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
    events: [
      {
        name: 'change',
        value: 'string',
      },
    ],
  },
}
