module.exports = {
  'v-stepper-header': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
