module.exports = {
  'v-resize': {
    argument: [{
      name: 'argument',
      type: ['Function'],
      default: undefined,
    }],
    modifiers: [
      {
        name: 'quiet',
        default: 'false',
        type: ['boolean'],
      },
    ],
  },
}
