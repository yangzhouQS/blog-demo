module.exports = {
  'v-list-item-action': {
    slots: [
      {
        name: 'default',
        props: undefined,
      },
    ],
  },
}
