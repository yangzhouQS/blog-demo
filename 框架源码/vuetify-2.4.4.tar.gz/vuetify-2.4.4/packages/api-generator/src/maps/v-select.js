const { VSelect } = require('../helpers/variables')

module.exports = {
  'v-select': VSelect,
}
