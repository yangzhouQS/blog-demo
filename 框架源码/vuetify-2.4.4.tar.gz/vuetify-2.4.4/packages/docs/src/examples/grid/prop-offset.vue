<template>
  <v-container class="grey lighten-5">
    <v-row
      class="mb-6"
      no-gutters
    >
      <v-col md="4">
        <v-card
          class="pa-2"
          outlined
          tile
        >
          .col-md-4
        </v-card>
      </v-col>
      <v-col
        md="4"
        offset-md="4"
      >
        <v-card
          class="pa-2"
          outlined
          tile
        >
          .col-md-4 .offset-md-4
        </v-card>
      </v-col>
    </v-row>
    <v-row
      class="mb-6"
      no-gutters
    >
      <v-col
        md="3"
        offset-md="3"
      >
        <v-card
          class="pa-2"
          outlined
          tile
        >
          .col-md-3 .offset-md-3
        </v-card>
      </v-col>
      <v-col
        md="3"
        offset-md="3"
      >
        <v-card
          class="pa-2"
          outlined
          tile
        >
          .col-md-3 .offset-md-3
        </v-card>
      </v-col>
    </v-row>
    <v-row no-gutters>
      <v-col
        md="6"
        offset-md="3"
      >
        <v-card
          class="pa-2"
          outlined
          tile
        >
          .col-md-6 .offset-md-3
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>
