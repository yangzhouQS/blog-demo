<template>
  <div>
    <div class="d-inline pa-2 deep-purple accent-4 white--text">
      d-inline
    </div>
    <div class="d-inline pa-2 black white--text">
      d-inline
    </div>
  </div>
</template>
