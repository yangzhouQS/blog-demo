
<template>
  <v-row justify="center">
    <v-col
      cols="12"
      md="3"
    >
      <div
        class="pa-4 text-center secondary rounded-0"
        v-text="`.rounded-0`"
      ></div>
    </v-col>
  </v-row>
</template>
