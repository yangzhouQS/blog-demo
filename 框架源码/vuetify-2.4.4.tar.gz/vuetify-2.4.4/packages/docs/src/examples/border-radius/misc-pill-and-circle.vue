<template>
  <v-row class="text-center" justify="center">
    <v-col
      cols="12"
      md="3"
    >
      <div
        class="pa-4 secondary text-no-wrap rounded-pill"
      >
        .rounded-pill
      </div>
    </v-col>

    <v-col
      cols="12"
      md="3"
    >
      <div
        class="pa-7 secondary rounded-circle d-inline-block"
      ></div>

      <div>.rounded-circle</div>
    </v-col>
  </v-row>
</template>
