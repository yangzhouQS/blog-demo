<template>
  <div
    class="text-no-wrap secondary"
    style="width: 8rem;"
  >
    This text should overflow the parent.
  </div>
</template>
