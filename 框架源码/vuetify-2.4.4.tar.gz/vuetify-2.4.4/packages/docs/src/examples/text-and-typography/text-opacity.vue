<template>
  <div>
    <p class="text--primary">
      High-emphasis has an opacity of 87%.
    </p>
    <p class="text--secondary">
      Medium-emphasis text and hint text have opacities of 60%.
    </p>
    <p class="text--disabled">
      Disabled text has an opacity of 38%.
    </p>
  </div>
</template>
