<template>
  <v-card
    class="pa-md-4 mx-lg-auto"
    color="secondary"
    width="250px"
  >
    <v-card-text>
      Adjust screen size to see spacing changes
    </v-card-text>
  </v-card>
</template>
