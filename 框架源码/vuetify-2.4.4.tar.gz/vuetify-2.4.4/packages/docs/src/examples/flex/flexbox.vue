<template>
  <v-card
    class="d-flex pa-2"
    outlined
    tile
  >
    <div>
      I'm a flexbox container!
    </div>
  </v-card>
</template>
