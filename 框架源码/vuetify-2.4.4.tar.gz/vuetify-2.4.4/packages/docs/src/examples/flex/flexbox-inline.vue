<template>
  <v-card
    class="d-inline-flex pa-2"
    outlined
    tile
  >
    <div>
      I'm an inline flexbox container!
    </div>
  </v-card>
</template>
