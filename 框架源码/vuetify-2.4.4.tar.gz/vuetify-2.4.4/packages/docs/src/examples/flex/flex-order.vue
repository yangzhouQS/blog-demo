<template>
  <div>
    <v-card
      class="d-flex flex-wrap-reverse"
      color="grey lighten-2"
      flat
      tile
    >
      <v-card
        class="order-3 pa-2"
        outlined
        tile
      >
        First flex item
      </v-card>
      <v-card
        class="order-2 pa-2"
        outlined
        tile
      >
        Second flex item
      </v-card>
      <v-card
        class="order-1 pa-2"
        outlined
        tile
      >
        Third flex item
      </v-card>
    </v-card>
  </div>
</template>
