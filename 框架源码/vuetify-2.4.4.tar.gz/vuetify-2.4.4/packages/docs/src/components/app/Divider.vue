<template>
  <v-divider class="my-6" />
</template>

<script>
  export default { name: 'AppDivider' }
</script>
