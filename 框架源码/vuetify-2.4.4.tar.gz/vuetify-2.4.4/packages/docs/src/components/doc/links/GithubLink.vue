<template>
  <app-tooltip-btn
    href="https://github.com/vuetifyjs/vuetify"
    icon="$mdiGithub"
    path="github"
    rel="noopener"
    target="_blank"
  />
</template>

<script>
  export default { name: 'GithubLink' }
</script>
