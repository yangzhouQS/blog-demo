<template>
  <app-tooltip-btn
    href="https://discord.gg/HJXwxMy"
    icon="$mdiDiscord"
    path="discord"
    rel="noopener"
    target="_blank"
  />
</template>

<script>
  export default { name: 'DiscordLink' }
</script>
