<template>
  <app-tooltip-btn
    href="https://store.vuetifyjs.com/?utm_source=vuetifyjs.com&utm_medium=toolbar"
    icon="$mdiShoppingOutline"
    path="store"
    rel="noopener"
    target="_blank"
  />
</template>

<script>
  export default { name: 'StoreLink' }
</script>
