---
name: '⚠️  Please use Mand Mobile Issue Helper ⚠️'
about: The issue which is not created via https://mand-mobile.github.io/mand-mobile-issue-helper/?project=mand-mobile  will be closed immediately. 不是用Mand Mobile Issue Helper创建的issue会被立即关闭。
labels:
---

The issue which is not created via <a href="https://mand-mobile.github.io/mand-mobile-issue-helper/?project=mand-mobile">Mand Mobile Issue Helper</a> will be closed immediately.

---

注意：不是用 <a href="https://mand-mobile.github.io/mand-mobile-issue-helper/?project=mand-mobile">Mand Mobile Issue Helper</a> 创建的 issue 会被立即关闭。