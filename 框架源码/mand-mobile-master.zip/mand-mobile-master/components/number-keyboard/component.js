export default {
  'name': 'number-keyboard',
  'text': '数字键盘',
  'category': 'form',
  'description': '',
  'author': 'xuxiaoyan'
}
