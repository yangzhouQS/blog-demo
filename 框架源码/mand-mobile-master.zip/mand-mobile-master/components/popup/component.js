export default {
  'name': 'popup',
  'text': '弹出层',
  'category': 'feedback',
  'description': '',
  'author': 'xuxiaoyan'
}
