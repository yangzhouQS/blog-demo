export default {
  "name": "date-picker",
  "text": "日期选择器",
  "category": "feedback",
  "description": "",
  "author": "xuxiaoyan"
}
