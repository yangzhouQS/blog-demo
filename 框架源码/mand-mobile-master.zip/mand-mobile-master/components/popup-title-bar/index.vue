<script>import PopupTitleBar from '../popup/title-bar'
export default PopupTitleBar
</script>

