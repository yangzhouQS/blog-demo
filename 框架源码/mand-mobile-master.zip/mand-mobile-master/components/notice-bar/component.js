export default {
  'name': 'notice-bar',
  'text': '通告栏',
  'category': 'basic',
  'description': '通告栏',
  'author': 'linyufei'
}
