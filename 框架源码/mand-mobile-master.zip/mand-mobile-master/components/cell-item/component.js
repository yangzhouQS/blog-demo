export default {
  'name': 'cell-item',
  'text': '列表单元',
  'category': 'basic',
  'description': '列表用于展现并列层级的信息内容，列表可承载功能入口、功能操作、信息展示等功能',
  'author': 'moyu <moyuboy@gmail.com>'
}
