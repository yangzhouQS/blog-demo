export default {
  "name": "activity-indicator",
  "text": "活动指示器",
  "category": "basic",
  "description": "",
  "author": "xuxiaoyan"
}
