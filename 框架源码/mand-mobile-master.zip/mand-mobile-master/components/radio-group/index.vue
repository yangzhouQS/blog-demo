<script>import RadioGroup from '../radio/group'
export default RadioGroup
</script>
