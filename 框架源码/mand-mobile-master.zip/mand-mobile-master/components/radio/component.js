export default {
  'name': 'radio',
  'text': '单选框',
  'category': 'form',
  'description': '',
  'author': 'moyu <moyuboy@gmail.com>'
}
