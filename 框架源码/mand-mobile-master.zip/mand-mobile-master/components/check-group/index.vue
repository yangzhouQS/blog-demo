<script>import CheckGroup from '../check/group'
export default CheckGroup
</script>
