export default {
  'name': 'input-item',
  'text': '输入框',
  'category': 'form',
  'description': '',
  'author': 'xuxiaoyan'
}
