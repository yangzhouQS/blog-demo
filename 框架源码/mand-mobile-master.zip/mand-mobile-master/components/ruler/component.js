export default {
  'name': 'ruler',
  'text': '刻度尺',
  'category': 'business',
  'description': '刻度尺',
  'author': 'supergaojian <402853745@qq.com>'
}