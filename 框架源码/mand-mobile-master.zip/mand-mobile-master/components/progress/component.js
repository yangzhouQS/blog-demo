export default {
  "name": "progress",
  "text": "进度",
  "category": "basic",
  "description": "",
  "author": "xuxiaoyan"
}