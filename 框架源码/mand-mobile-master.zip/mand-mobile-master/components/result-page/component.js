export default {
  'name': 'result-page',
  'text': '结果页',
  'category': 'business',
  'description': '用于展示流程终点页面的组件。',
  'author': 'zhaozhe'
}
