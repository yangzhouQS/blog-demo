export default {
  'name': 'check',
  'text': '复选项',
  'category': 'form',
  'description': '',
  'author': 'moyu <moyuboy@gmail.com>'
}
