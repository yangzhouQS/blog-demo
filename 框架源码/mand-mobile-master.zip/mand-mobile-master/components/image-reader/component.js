export default {
  'name': 'image-reader',
  'text': '图片选择器',
  'category': 'basic',
  'description': '',
  'author': 'xuxiaoyan'
}
