export default {
  'name': 'field',
  'text': '组合列表',
  'category': 'form',
  'description': '单个连续模块垂直排列，显示当前的内容、状态和可进行的操作',
  'author': 'moyu <moyuboy@gmail.com>'
}
