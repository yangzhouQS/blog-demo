<script>import CheckBox from '../check/box'
export default CheckBox
</script>
