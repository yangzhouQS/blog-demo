export default {
  'name': 'agree',
  'text': '单选框',
  'category': 'form',
  'description': '',
  'author': 'chengyanjing'
}
