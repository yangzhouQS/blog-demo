export default {
  'name': 'landscape',
  'text': '压屏',
  'category': 'business',
  'description': '用于展示压屏广告或通知的组件。',
  'author': 'zhaozhe'
}
