export default {
  'name': 'dialog',
  'text': '模态窗口',
  'category': 'feedback',
  'description': '弹出式交互窗口',
  'author': 'moyu <moyuboy@gmail.com>'
}
