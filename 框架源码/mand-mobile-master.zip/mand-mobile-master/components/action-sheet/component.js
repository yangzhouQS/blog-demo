export default {
  'name': 'action-sheet',
  'text': '底部弹窗',
  'category': 'feedback',
  'description': '',
  'author': 'qiman'
}
