export default {
  'name': 'captcha',
  'text': '验证码窗口',
  'category': 'business',
  'description': '交互式验证码校验弹窗',
  'author': 'moyu <moyuboy@gmail.com>'
}
