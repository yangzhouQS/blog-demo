export default {
  'name': 'image-viewer',
  'text': '图片查看器',
  'category': 'basic',
  'description': '图片查看器',
  'author': 'linyufei'
}
