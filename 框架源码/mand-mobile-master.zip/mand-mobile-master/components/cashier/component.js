export default {
  "name": "cashier",
  "text": "收银台",
  "category": "business",
  "description": "",
  "author": "xuxiaoyan"
}
