<script>import RadioList from '../radio/list'
export default RadioList
</script>
