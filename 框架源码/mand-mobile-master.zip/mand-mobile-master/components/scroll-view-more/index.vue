<script>import ScrollViewMore from '../scroll-view/more'
export default ScrollViewMore
</script>
