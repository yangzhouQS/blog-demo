export default {
  'name': 'drop-menu',
  'text': '下拉菜单',
  'category': 'basic',
  'description': '',
  'author': 'xuxiaoyan'
}
