export default {
  'name': 'action-bar',
  'text': '操作栏',
  'category': 'basic',
  'description': '',
  'author': 'xuxiaoyan'
}
