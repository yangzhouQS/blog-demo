export default {
  "name": "bill",
  "text": "票据",
  "category": "business",
  "description": "",
  "author": "xuxiaoyan"
}
