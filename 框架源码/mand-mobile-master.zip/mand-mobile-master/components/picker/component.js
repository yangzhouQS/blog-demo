export default {
  'name': 'picker',
  'text': '选择器',
  'category': 'feedback',
  'description': '',
  'author': 'xuxiaoyan'
}
