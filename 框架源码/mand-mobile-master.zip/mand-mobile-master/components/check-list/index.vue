<script>import CheckList from '../check/list'
export default CheckList
</script>
