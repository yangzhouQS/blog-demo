export default {
  'name': 'chart',
  'text': '折线图表',
  'category': 'business',
  'description': '基于 SVG 的折线图表组件',
  'author': 'moyu <moyuboy@gmail.com>'
}
