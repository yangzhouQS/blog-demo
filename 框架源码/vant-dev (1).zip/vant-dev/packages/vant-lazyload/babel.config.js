module.exports = {
  presets: [['@vant/cli/preset', { loose: true }]],
};
