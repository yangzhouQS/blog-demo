module.exports = {
  presets: ['@vant/cli/preset'],
};
