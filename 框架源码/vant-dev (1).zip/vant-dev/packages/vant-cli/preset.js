const babelConfig = require('./lib/config/babel.config');

module.exports = (api, options) => babelConfig(api, options);
