# Stylelint Config of Vant

## Install

#### NPM

```shell
npm i @vant/stylelint-config -D
```

#### YARN

```shell
yarn add @vant/stylelint-config --dev
```

## Usage

```js
{
  "extends": ["@vant/stylelint-config"]
}
```
