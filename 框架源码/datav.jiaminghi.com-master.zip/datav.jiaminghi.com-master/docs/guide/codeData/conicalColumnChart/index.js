import conicalColumnChart1 from './demo1'
import conicalColumnChart2 from './demo2'

export default {
  conicalColumnChart1,
  conicalColumnChart2
}