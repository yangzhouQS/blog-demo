import scrollRankingBoard1 from './demo1'
import scrollRankingBoard2 from './demo2'
import scrollRankingBoard3 from './demo3'
import scrollRankingBoard4 from './demo4'

export default {
  scrollRankingBoard1,
  scrollRankingBoard2,
  scrollRankingBoard3,
  scrollRankingBoard4
}