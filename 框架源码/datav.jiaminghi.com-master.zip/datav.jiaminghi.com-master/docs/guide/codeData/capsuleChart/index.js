import capsuleChart1 from './demo1'
import capsuleChart2 from './demo2'
import capsuleChart3 from './demo3'
import capsuleChart4 from './demo4'

export default {
  capsuleChart1,
  capsuleChart2,
  capsuleChart3,
  capsuleChart4
}