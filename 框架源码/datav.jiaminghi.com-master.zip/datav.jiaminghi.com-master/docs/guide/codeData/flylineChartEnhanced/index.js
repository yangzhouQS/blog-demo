import flylineChartEnhanced1 from './demo1'
import flylineChartEnhanced2 from './demo2'
import flylineChartEnhanced3 from './demo3'
import flylineChartEnhanced4 from './demo4'
import flylineChartEnhanced5 from './demo5'
import flylineChartEnhanced6 from './demo6'

export default {
  flylineChartEnhanced1,
  flylineChartEnhanced2,
  flylineChartEnhanced3,
  flylineChartEnhanced4,
  flylineChartEnhanced5,
  flylineChartEnhanced6
}