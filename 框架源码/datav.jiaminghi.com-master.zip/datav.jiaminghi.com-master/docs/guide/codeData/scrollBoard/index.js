import scrollBoard1 from './demo1'
import scrollBoard2 from './demo2'
import scrollBoard3 from './demo3'
import scrollBoard4 from './demo4'
import scrollBoard5 from './demo5'

export default {
  scrollBoard1,
  scrollBoard2,
  scrollBoard3,
  scrollBoard4,
  scrollBoard5
}