const config1 = {
  number: [10, 100],
  content: '{nt}个{nt}元'
}

const config2 = {
  number: [100, 1000],
  content: '{nt}个{nt}元'
}

export default [
  config1,
  config2
]