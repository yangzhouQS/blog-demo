import digitalFlop1 from './demo1'
import digitalFlop2 from './demo2'
import digitalFlop3 from './demo3'
import digitalFlop4 from './demo4'

export default {
  digitalFlop1,
  digitalFlop2,
  digitalFlop3,
  digitalFlop4
}