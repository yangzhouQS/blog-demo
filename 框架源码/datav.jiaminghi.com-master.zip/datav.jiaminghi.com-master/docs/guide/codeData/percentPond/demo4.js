export default {
  value: 66,
  localGradient: true
}