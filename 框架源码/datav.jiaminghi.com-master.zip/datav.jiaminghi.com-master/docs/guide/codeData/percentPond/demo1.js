export default {
  value: 66
}