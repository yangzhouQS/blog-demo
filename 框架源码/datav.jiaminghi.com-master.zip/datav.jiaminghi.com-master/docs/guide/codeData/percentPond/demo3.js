export default {
  value: 66,
  lineDash: [10, 2]
}