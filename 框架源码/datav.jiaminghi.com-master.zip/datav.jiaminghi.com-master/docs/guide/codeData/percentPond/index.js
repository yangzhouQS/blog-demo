import percentPond1 from './demo1'
import percentPond2 from './demo2'
import percentPond3 from './demo3'
import percentPond4 from './demo4'
import percentPond5 from './demo5'

export default {
  percentPond1,
  percentPond2,
  percentPond3,
  percentPond4,
  percentPond5
}