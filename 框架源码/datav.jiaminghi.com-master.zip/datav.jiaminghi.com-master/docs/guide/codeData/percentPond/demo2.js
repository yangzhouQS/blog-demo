export default {
  value: 66,
  borderWidth: 5,
  borderRadius: 10,
  borderGap: 5
}