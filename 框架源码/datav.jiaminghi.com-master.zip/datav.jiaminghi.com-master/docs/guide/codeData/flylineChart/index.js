import flylineChart1 from './demo1'
import flylineChart2 from './demo2'
import flylineChart3 from './demo3'
import flylineChart4 from './demo4'

export default {
  flylineChart1,
  flylineChart2,
  flylineChart3,
  flylineChart4
}