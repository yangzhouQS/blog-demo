import activeRingChart1 from './demo1'
import activeRingChart2 from './demo2'
import activeRingChart3 from './demo3'
import activeRingChart4 from './demo4'

export default {
  activeRingChart1,
  activeRingChart2,
  activeRingChart3,
  activeRingChart4
}