export default {
  data: [66]
}