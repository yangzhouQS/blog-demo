export default {
  data: [66, 45],
  shape: 'roundRect'
}