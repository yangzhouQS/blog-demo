import waterLevelPond1 from './demo1'
import waterLevelPond2 from './demo2'
import waterLevelPond3 from './demo3'

export default {
  waterLevelPond1,
  waterLevelPond2,
  waterLevelPond3
}