export default {
  data: [55],
  shape: 'round'
}