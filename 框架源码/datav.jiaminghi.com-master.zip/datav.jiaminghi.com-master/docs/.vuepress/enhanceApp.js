import auxiliary from '../auxiliary/index'

import dataV from '../DataV/index'

export default ({
  Vue,
}) => {
  Vue.use(auxiliary)
  Vue.use(dataV)
}
