import BorderBox7 from './src/main.vue'

export default function (Vue) {
  Vue.component(BorderBox7.name, BorderBox7)
}
