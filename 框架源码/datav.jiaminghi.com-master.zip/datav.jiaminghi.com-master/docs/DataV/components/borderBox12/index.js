import BorderBox12 from './src/main.vue'

export default function (Vue) {
  Vue.component(BorderBox12.name, BorderBox12)
}
