# 支持

## [Charts](http://charts.jiaminghi.com)

提供了图表支持。

## [CRender](http://crender.jiaminghi.com)

提供了Canvas渲染支持。

## [Transition](http://transition.jiaminghi.com)

提供了缓动曲线、动画状态的支持。