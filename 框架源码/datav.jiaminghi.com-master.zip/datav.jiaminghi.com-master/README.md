<h1 align="center"><a href="http://datav.jiaminghi.com">datav.jiaminghi.com</a></h1>

<p align="center">
    <a href="https://github.com/DataV-Team/datav.jiaminghi.com/blob/master/LICENSE"><img src="https://img.shields.io/github/license/DataV-Team/datav.jiaminghi.com.svg" alt="LICENSE" />
</p>

### Project setup

```shell
yarn
```

### Compiles and hot-reloads for development

```shell
yarn dev
```

### Compiles and minifies for production

```shell
yarn build
```

[Datav](https://github.com/DataV-Team/Datav)