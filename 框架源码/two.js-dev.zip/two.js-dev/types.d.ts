// This is work-in-progress on the `es6` branch
// https://github.com/jonobr1/two.js/tree/es6
declare module "two.js"
