<script lang="ts">
import { createComponent } from '../../utils/create';
const { create } = createComponent('layout');
export default create({});
</script>
