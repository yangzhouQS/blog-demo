# Video 视频播放器

### 介绍

原生video实现的视频播放器

#### 直接使用 Taro 现有 video 组件开发 [参考文档](https://docs.taro.zone/docs/components/media/video)