# ImagePreview 图片预览


#### 直接使用 Taro 现有 previewImage 组件开发 [参考文档](https://docs.taro.zone/docs/apis/media/image/previewImage)