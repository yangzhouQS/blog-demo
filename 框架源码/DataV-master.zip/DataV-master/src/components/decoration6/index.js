import Decoration6 from './src/main.vue'

export default function (Vue) {
  Vue.component(Decoration6.name, Decoration6)
}
