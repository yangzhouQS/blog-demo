import Decoration10 from './src/main.vue'

export default function (Vue) {
  Vue.component(Decoration10.name, Decoration10)
}
