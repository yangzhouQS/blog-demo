import BorderBox2 from './src/main.vue'

export default function (Vue) {
  Vue.component(BorderBox2.name, BorderBox2)
}
