---
name: Feature request
about: 新特性建议
---

<!-- 创建新特性建议前请确定你的DataV是最新版的 -->

## Feature request

#### 这个特性解决了什么问题？

#### 这个特性的实现形式？

#### 是否愿意为此特性提交PR？
