## better-scroll module

This module exports a default function called `BetterScroll`,  for more information about better-scroll, please refer to [better-scroll lib](https://github.com/ustbhuangyi/better-scroll).

### Links

About better-scroll:

- [Home](https://better-scroll.github.io/docs-v1/#/)

- [Example](https://better-scroll.github.io/docs-v1/#/examples/en)
