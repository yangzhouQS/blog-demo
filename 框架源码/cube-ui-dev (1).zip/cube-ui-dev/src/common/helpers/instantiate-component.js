import createAPI from 'vue-create-api'
const { instantiateComponent } = createAPI

export default instantiateComponent
