({
  'outer': {
    'id': 1,
    'second': {
      'nothing': 2
    }
  }
});
