({
  items: [
    {
      name: 'name',
      items: [1, 2, 3, 4]
    }
  ]
});
