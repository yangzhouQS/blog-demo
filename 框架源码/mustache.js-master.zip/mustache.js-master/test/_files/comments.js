({
  title: function () {
    return 'A Comedy of Errors';
  }
});
