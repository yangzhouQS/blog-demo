import * as NutUI from './nutui';
export default NutUI;
export * from './nutui';
