import { shallowMount, mount } from '@vue/test-utils'
import LuckyCard from '../luckycard.vue';
import Vue from 'vue';
		
describe('LuckyCard.vue', () => {
			
});