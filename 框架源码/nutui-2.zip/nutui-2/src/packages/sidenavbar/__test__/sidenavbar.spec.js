import { shallowMount } from '@vue/test-utils';
import Vue from 'vue';
import SideNavBar from '../sidenavbar.vue';

describe('SideNavBar.vue', () => {
    
});