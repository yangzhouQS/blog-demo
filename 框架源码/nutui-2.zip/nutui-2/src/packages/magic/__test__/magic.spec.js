import { shallowMount, mount } from '@vue/test-utils';
import Magic from '../magic.vue';
import Vue from 'vue';

describe('Magic.vue', () => {});
