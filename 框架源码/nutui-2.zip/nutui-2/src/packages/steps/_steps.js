import Steps from './steps.vue';
import Step from './Step.vue';

Steps.Step = Step;
export default Steps;
