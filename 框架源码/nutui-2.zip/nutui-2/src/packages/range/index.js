import Range from './range.vue';
import './range.scss';

Range.install = function(Vue) {
  Vue.component(Range.name, Range);
};

export default Range;
