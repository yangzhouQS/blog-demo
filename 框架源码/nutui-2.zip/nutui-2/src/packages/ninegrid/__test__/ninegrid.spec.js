import { shallowMount, mount } from '@vue/test-utils';
import NineGrid from '../ninegrid.vue';
import Vue from 'vue';

describe('NineGrid.vue', () => {});
