import Lazyload from 'vue-lazyload';
Lazyload.name = 'vue-lazyload';
import './lazyload.scss';
export default Lazyload;
