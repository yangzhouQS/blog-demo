import Row from '../row/row.vue';
import Col from '../col/col.vue';

export { Row, Col };
