<template>
  <div class="">
    <nut-timelineitem></nut-timelineitem>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {};
  },
  methods: {}
};
</script>

<style lang="scss" scoped></style>
