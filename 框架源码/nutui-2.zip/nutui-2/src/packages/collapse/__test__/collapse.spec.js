import { shallowMount, mount } from '@vue/test-utils';
import Collapse from '../collapse.vue';
import Vue from 'vue';

describe('Collapse.vue', () => {});
