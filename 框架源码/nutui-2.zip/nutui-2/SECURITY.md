# Security Policy

## Reporting a Vulnerability

Send information about security vulnerabilities to nutui@jd.com
