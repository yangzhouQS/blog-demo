module.exports = {
  extends: ['plugin:vue/essential'],
  rules: {},
  parserOptions: {
    parser: 'babel-eslint',
    ecmaVersion: 2017
  }
};
