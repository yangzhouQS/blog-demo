require('jsdom-global')();
window.Date = Date;
global.expect = require('expect');