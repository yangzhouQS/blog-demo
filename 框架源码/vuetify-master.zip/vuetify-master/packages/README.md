<p>These are the packages for the <a href="https://vuetifyjs.com" target="_blank">Vuetify</a> monorepo.</p>

## Packages for the Vuetify

1. **api-generator** - generates api for Vuetify docs and other resources.
2. **docs** - Vuetify documentation
3. **vuetify** - main source code for Vuetify
