<template>
  <base-heading id="up-next">Generic.Pages.upNext</base-heading>
</template>

<script>
  export default {
    name: 'UpNextHeading',
  }
</script>
