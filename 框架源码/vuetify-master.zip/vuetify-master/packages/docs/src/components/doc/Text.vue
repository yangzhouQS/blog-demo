<template functional>
  <base-markdown><slot /></base-markdown>
</template>
