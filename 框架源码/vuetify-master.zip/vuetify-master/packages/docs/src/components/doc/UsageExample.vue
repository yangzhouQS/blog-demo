<template>
  <v-card
    class="mx-auto example-new mb-12"
    max-width="1200"
    outlined
  >
    <v-row no-gutters>
      <v-col
        cols="12"
        md="9"
      >
        <div
          :class="$vuetify.theme.dark ? 'grey darken-4' : 'grey lighten-3'"
          class="d-flex"
        >
          <v-tabs
            v-model="tab"
            background-color="transparent"
            class="pl-0 pl-md-6"
            color="primary"
          >
            <v-tab
              v-for="(t) in value.tabs"
              :key="t"
              :value="t"
              v-text="t"
            />
          </v-tabs>

          <v-divider vertical />
        </div>

        <v-responsive
          v-if="component"
          class="child-flex overflow-hidden"
          height="400"
        >
          <v-sheet
            id="usage-example"
            :dark="dark || $vuetify.theme.dark"
            class="d-inline-block"
            width="calc(100% - 1px)"
            height="400"
            style="overflow-y: auto;"
            tile
          >
            <div
              class="fill-height pa-6 d-flex align-center"
              data-app="true"
            >
              <component
                :is="component"
                :attrs="attrs$"
              />
            </div>
          </v-sheet>

          <v-divider
            class="hidden-sm-and-down"
            vertical
          />
        </v-responsive>
      </v-col>

      <v-col
        cols="12"
        md="3"
      >
        <div
          :class="$vuetify.theme.dark ? 'grey darken-4' : 'grey lighten-3'"
          class="d-flex"
        >
          <v-responsive
            class="title font-weight-regular align-center px-3"
            height="48"
          >
            Options
          </v-responsive>

          <v-tooltip
            v-if="!$vuetify.theme.dark"
            bottom
          >
            <template v-slot:activator="{ on }">
              <v-btn
                aria-label="Invert playground colors"
                class="flex-shrink-1 mx-2 mt-2"
                icon
                @click="dark = !dark"
                v-on="on"
              >
                <v-icon>mdi-invert-colors</v-icon>
              </v-btn>
            </template>

            Invert playground colors
          </v-tooltip>
        </div>

        <v-divider />

        <v-responsive
          max-height="300"
          class="overflow-y-auto py-3"
        >
          <v-col
            v-for="(input, i) in value.inputs || []"
            :key="`col-0-${i}`"
            cols="12"
            class="pb-0"
          >
            <v-text-field
              v-model="inputs[input.prop]"
              v-bind="input.attrs"
              :label="input.label"
              hide-details
            />
          </v-col>

          <v-col
            v-for="(v1, boolean, i) in booleans || {}"
            :key="`col-1-${i}`"
            cols="12"
            class="pb-0"
          >
            <v-switch
              v-model="booleans[boolean]"
              class="mt-0"
              hide-details
              inset
            >
              <template v-slot:label>
                <span
                  class="text-capitalize"
                  v-text="boolean"
                />
              </template>
            </v-switch>
          </v-col>

          <v-col
            v-for="(slider, i) in value.sliders || []"
            :key="`col-2-${i}`"
            cols="12"
            class="pb-0"
          >
            <v-slider
              v-model="sliders[Object(slider) === slider ? slider.prop : slider]"
              v-bind="{
                min: slider === 'elevation' ? 0 : undefined,
                max: slider === 'elevation' ? 24 : undefined,
                ...(Object(slider) === slider ? (slider.attrs || {}) : {}),
              }"
              hide-details
            >
              <template v-slot:label>
                <span class="text-capitalize">
                  <template v-if="slider === 'elevation'">Elevation</template>
                  <template v-else-if="Object(slider) === slider">
                    {{ slider.label || (slider.prop || '').replace('-', ' ') }}
                  </template>
                </span>
              </template>
            </v-slider>
          </v-col>

          <v-col
            v-for="(select, i) in value.selects || []"
            :key="`col-3-${i}`"
            cols="12"
            class="pb-0"
          >
            <v-select
              v-model="selects[select.prop]"
              v-bind="select.attrs"
              :hide-details="i + 1 !== (value.selects || []).length"
              :label="select.label"
              clearable
              dense
              filled
            />
          </v-col>
        </v-responsive>
      </v-col>
    </v-row>
  </v-card>
</template>

<script>
  // Utilities
  import {
    mapGetters,
  } from 'vuex'
  import kebabCase from 'lodash/kebabCase'

  function setupData (values = []) {
    return values.reduce((acc, cur) => {
      if (Object(cur) !== cur) {
        acc[cur] = null
        return acc
      }

      acc[cur.prop] = cur.value

      return acc
    }, {})
  }

  export default {
    name: 'DocUsageExampleNew',

    props: {
      value: {
        type: Object,
        default: () => ({
          booleans: [],
          inputs: [],
          sliders: [],
          selects: [],
          tabs: [],
        }),
      },
    },

    data () {
      return {
        booleans: setupData(this.value.booleans),
        component: null,
        dark: false,
        inputs: setupData(this.value.inputs),
        selects: setupData(this.value.selects),
        sliders: setupData(this.value.sliders),
        tab: 0,
        tabs: setupData(this.value.tabs),
      }
    },

    computed: {
      ...mapGetters('documentation', [
        'page',
      ]),
      attrs$ () {
        const attrs = {}

        if ((this.value.tabs || []).length > 0) {
          attrs[this.value.tabs[this.tab]] = true
        }

        this.parseAttrs(this.booleans, attrs)
        this.parseAttrs(this.inputs, attrs)
        this.parseAttrs(this.sliders, attrs)
        this.parseAttrs(this.selects, attrs)

        return attrs
      },
      file () {
        return `${this.kebabCase(this.page)}`
      },
    },

    mounted () {
      this.importComponent()
    },

    methods: {
      importComponent () {
        return import(
          /* webpackChunkName: "usages" */
          `../../usages/${this.file}.vue`
        )
          .then(comp => (this.component = comp.default))
      },
      kebabCase,
      parseAttrs (values, attrs) {
        for (const key in values) {
          const value = values[key]

          if (Object(value) === value) this.parseAttrs(attrs, value)
          else attrs[key] = value
        }
      },
    },
  }
</script>

<style lang="sass">
  .example-new
    .v-tabs
      border-bottom: thin solid rgba(0, 0, 0, 0.12) !important
      border-bottom-left-radius: 0 !important
      border-bottom-right-radius: 0 !important

      &.theme--dark
        border-bottom: thin solid rgba(255, 255, 255, 0.12) !important
</style>
