<template>
  <v-btn
    active-class=""
    color="#24292e"
    dark
    href="https://github.com/users/johnleider/sponsorship"
    large
    rel="noopener"
    target="_blank"
    title="Support Vuetify through Github"
  >
    <v-icon left>mdi-github</v-icon>
    <span
      class="font-weight-black"
      v-text="`Become a Sponsor`"
    />
  </v-btn>
</template>
