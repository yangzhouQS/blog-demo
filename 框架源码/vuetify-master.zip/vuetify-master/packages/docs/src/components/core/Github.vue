<template>
  <v-layout
    align-center
    ml-2
    shrink
  >
    <iframe
      src="https://ghbtns.com/github-btn.html?user=vuetifyjs&repo=vuetify&type=star&count=true"
      frameborder="0"
      scrolling="0"
      width="100px"
      height="20px"
      title="Star Vuetify on Github"
    />
  </v-layout>
</template>
