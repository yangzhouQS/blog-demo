<template>
  <v-divider></v-divider>
</template>
