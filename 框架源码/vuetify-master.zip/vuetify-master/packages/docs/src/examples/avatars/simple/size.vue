<template>
  <v-row justify="space-around">

    <v-avatar color="indigo" size="36">
      <span class="white--text headline">36</span>
    </v-avatar>

    <v-avatar color="teal" size="48">
      <span class="white--text headline">48</span>
    </v-avatar>

    <v-avatar color="orange" size="62">
      <span class="white--text headline">62</span>
    </v-avatar>

  </v-row>
</template>
