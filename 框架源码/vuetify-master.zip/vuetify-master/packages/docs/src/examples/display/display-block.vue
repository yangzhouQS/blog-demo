<template>
  <div>
    <div class="d-block pa-2 deep-purple accent-4 white--text">d-block</div>
    <div class="d-block pa-2 black white--text">d-block</div>
  </div>
</template>
