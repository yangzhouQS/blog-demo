<template>
  <div>
    <v-file-input chips multiple label="File input w/ chips"></v-file-input>
    <v-file-input small-chips multiple label="File input w/ small chips"></v-file-input>
  </div>
</template>
