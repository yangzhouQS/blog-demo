<template>
  <v-file-input
    label="File input"
    filled
    prepend-icon="mdi-camera"
  ></v-file-input>
</template>
