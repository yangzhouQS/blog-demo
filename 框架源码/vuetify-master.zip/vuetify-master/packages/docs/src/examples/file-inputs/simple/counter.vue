<template>
  <v-file-input show-size counter multiple label="File input"></v-file-input>
</template>
