<template>
  <v-file-input accept="image/*" label="File input"></v-file-input>
</template>
