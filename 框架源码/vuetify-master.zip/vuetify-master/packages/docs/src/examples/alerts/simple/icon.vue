<template>
  <div>
    <v-alert
      color="#2A3B4D"
      dark
      icon="mdi-firework"
      dense
    >
      Suspendisse enim turpis, dictum sed, iaculis a, condimentum nec, nisi. Vivamus quis mi. Quisque ut nisi. Maecenas malesuada.

    </v-alert>
    <v-alert
      color="#C51162"
      dark
      icon="mdi-material-design"
      border="right"
    >
      Phasellus blandit leo ut odio. Morbi mattis ullamcorper velit. Donec orci lectus, aliquam ut, faucibus non, euismod id, nulla. In ut quam vitae odio lacinia tincidunt.
    </v-alert>
    <v-alert
      color="primary"
      dark
      icon="mdi-vuetify"
      border="left"
      prominent
    >
      Praesent congue erat at massa. Nullam vel sem. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Proin viverra, ligula sit amet ultrices semper, ligula arcu tristique sapien, a accumsan nisi mauris ac eros. Curabitur at lacus ac velit ornare lobortis.
    </v-alert>
  </div>
</template>
