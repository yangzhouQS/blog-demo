
<template>
  <v-container>
    <v-row justify="center">
      <v-col
        cols="12"
        md="2"
      >
        <div
          class="pa-6 text-center grey lighten-2 rounded-0"
          v-text="`.rounded-0`"
        ></div>
      </v-col>
    </v-row>
  </v-container>
</template>
