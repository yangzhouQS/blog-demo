<template>
  <v-container class="text-center">
    <v-responsive
      class="text-center grey lighten-2 rounded-pill d-inline-flex align-center justify-center ma-3"
      height="64"
      width="128"
    >
      Pill
    </v-responsive>

    <v-responsive
      class="text-center grey lighten-2 rounded-circle d-inline-flex align-center justify-center ma-3"
      height="64"
      width="64"
    >
      Circle
    </v-responsive>
  </v-container>
</template>
