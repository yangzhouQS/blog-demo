<template>
  <div class="text-center">
    <v-btn rounded color="primary" dark>Rounded Button</v-btn>
  </div>
</template>
