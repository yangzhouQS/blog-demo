<template>
  <v-btn block color="secondary" dark>Block Button</v-btn>
</template>
