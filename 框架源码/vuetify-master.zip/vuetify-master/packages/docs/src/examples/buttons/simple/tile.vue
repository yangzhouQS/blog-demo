<template>
  <div class="text-center">
    <v-btn class="ma-2" tile color="indigo" dark>Tile Button</v-btn>
    <v-btn class="ma-2" tile outlined color="success">
      <v-icon left>mdi-pencil</v-icon> Edit
    </v-btn>
    <v-btn class="ma-2" tile large color="teal" icon>
      <v-icon>mdi-vuetify</v-icon>
    </v-btn>
  </div>
</template>
