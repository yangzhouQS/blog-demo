<template>
  <div>
    Example of an inline <code>&lt;code&gt;</code> element.
  </div>
</template>
