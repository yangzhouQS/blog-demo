<template>
  <div>
    <var>v</var> = <var>u</var> * <var>e</var>
  </div>
</template>
