const { VInput } = require('../helpers/variables')

module.exports = {
  'v-switch': {
    ...VInput,
  },
}
