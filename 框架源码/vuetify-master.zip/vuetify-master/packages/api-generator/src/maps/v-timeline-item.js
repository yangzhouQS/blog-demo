module.exports = {
  'v-timeline-item': {
    slots: [
      {
        name: 'icon',
        props: undefined,
      },
      {
        name: 'opposite',
        props: undefined,
      },
    ],
  },
}
