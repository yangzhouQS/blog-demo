module.exports = {
  'v-container': {},
}
