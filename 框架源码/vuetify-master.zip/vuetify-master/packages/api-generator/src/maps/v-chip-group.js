module.exports = {
  'v-chip-group': {
    events: [
      {
        name: 'change',
        value: 'any[] | any',
      },
    ],
  },
}
