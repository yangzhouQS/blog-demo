module.exports = {
  'v-spacer': {
    slots: ['default'],
  },
}
