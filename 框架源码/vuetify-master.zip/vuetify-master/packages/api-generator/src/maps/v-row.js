module.exports = {
  'v-row': {
    slots: ['default'],
  },
}
