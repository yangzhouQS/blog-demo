module.exports = {
  'v-icon': {
    props: [
      {
        name: 'dense',
        type: 'boolean',
        default: 'false',
        source: null,
      },
    ],
  },
}
