module.exports = {
  'v-item': {
    slots: [
      {
        name: 'default',
        props: {
          active: 'boolean',
          toggle: 'Function',
        },
      },
    ],
  },
}
