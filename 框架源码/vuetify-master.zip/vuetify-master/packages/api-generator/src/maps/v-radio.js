const { VInput } = require('../helpers/variables')

module.exports = {
  'v-radio': {
    ...VInput,
  },
}
