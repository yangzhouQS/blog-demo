module.exports = {
  'v-list-item-group': {
    events: [
      {
        name: 'change',
        value: 'any[] | any',
      },
    ],
  },
}
