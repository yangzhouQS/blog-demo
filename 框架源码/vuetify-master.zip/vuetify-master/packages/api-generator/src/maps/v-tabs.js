module.exports = {
  'v-tabs': {
    events: [
      {
        name: 'change',
        value: 'number',
      },
    ],
  },
}
