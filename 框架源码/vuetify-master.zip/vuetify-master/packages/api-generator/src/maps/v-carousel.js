module.exports = {
  'v-carousel': {
    events: [
      {
        name: 'change',
        value: 'number',
      },
    ],
  },
}
