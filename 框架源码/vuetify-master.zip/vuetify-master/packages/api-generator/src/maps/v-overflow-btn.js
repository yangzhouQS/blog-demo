const { VSelect } = require('../helpers/variables')

module.exports = {
  'v-overflow-btn': VSelect,
}
