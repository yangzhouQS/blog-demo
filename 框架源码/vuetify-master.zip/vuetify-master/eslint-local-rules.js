'use strict'

module.exports = {
  'no-render-string-reference': {
    create: require('./scripts/no-render-string-reference'),
  },
}
