export { default } from './forEach.js'
