import { Konva } from './_FullInternals';

export default Konva;
