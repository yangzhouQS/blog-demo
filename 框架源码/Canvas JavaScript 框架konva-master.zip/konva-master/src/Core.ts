// enter file of limited Konva version with only core functions
export { Konva } from './_CoreInternals';
import { Konva } from './_CoreInternals';

export default Konva;
