import CRender from './core/crender.class'
export { default as Graph } from './core/graph.class'
export * from './graphs/index'
export { CRender }

export default CRender
