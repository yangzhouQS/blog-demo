export declare function bound(_: any, name: string, descriptor: PropertyDescriptor): PropertyDescriptor;
