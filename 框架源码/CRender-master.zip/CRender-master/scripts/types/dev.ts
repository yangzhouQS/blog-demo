export type ServerConfig = {
  open: boolean
  port: number
  server: {
    baseDir: string
  }
}
