---
home: true
heroImage: ./favicon.ico
actionText: 快速开始 →
actionLink: /guide/
features:
  - title: 简单易用
    details: 内置常用基础矢量图形，轻松自定义新图形，便于扩展和二次开发
  - title: 动感十足
    details: 搭配不同的缓动曲线，动画轻而易举
  - title: 便于交互
    details: 内置图形均支持hover、click、drag，快速在元素上添加交互，一步到位
footer: MIT Licensed | Copyright © 2018-present JiaMing
---
