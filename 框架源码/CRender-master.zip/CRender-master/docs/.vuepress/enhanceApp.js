import auxiliary from '../auxiliary/index'

export default ({ Vue }) => {
  Vue.use(auxiliary)
}
