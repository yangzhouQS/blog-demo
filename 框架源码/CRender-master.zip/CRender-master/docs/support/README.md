# 支持

## [Transition](http://transition.jiaminghi.com)

提供动画过渡数据 (animationCurve)。

如果你想扩展新的缓动曲线，请移步 [扩展新曲线](http://transition.jiaminghi.com/guide/#扩展缓动曲线)。

## [BezierCurve](https://github.com/DataV-Team/bezierCurve)

提供贝塞尔曲线支持，例如计算曲线长度，曲线折线互转。

## [Color](https://github.com/DataV-Team/Color)

提供了颜色计算，例如获取颜色的 rgba 值，以便于颜色动画状态的计算。
