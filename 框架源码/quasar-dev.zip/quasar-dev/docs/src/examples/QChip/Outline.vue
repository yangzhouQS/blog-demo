<template>
  <div class="q-pa-md">
    <q-chip outline color="primary" text-color="white" icon="event">
      Add to calendar
    </q-chip>
    <q-chip outline color="teal" text-color="white" icon="bookmark">
      Bookmark
    </q-chip>
    <q-chip outline color="orange" text-color="white" icon-right="star">
      Star
    </q-chip>
    <q-chip outline square color="red" text-color="white" icon="alarm" label="Set alarm" />
    <q-chip outline square color="deep-orange" text-color="white" icon="directions">
      Get directions
    </q-chip>
  </div>
</template>
