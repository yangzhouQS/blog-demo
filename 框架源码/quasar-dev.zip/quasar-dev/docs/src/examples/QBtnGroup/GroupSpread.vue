<template>
  <div class="q-pa-md">
    <q-btn-group spread>
      <q-btn color="purple" label="First" icon="timeline" />
      <q-btn color="purple" label="Second" icon="visibility" />
    </q-btn-group>
  </div>
</template>
