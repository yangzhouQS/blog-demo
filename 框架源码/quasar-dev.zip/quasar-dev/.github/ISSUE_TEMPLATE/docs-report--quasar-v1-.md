---
name: Docs report (Quasar v1)
about: Create a report to help us improve Quasar v1 docs
title: "[docs]"
labels: ":page_facing_up: docs, Qv1"
assignees: ''

---


