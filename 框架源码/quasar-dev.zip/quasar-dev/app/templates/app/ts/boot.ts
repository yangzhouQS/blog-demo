import { boot } from 'quasar/wrappers'

// "async" is optional;
// more info on params: https://quasar.dev/quasar-cli/boot-files
export default boot(async (/* { app, router, Vue ... } */) => {
  // something to do
})
