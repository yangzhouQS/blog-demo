<template>
  <div>My component</div>
</template>

<script lang="ts">
import Vue from 'vue'
export default Vue.extend({
  // name: 'ComponentName'
})
</script>
