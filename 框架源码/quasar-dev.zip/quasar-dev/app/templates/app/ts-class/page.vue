<template>
  <q-page padding>
    <!-- content -->
  </q-page>
</template>

<script lang="ts">
import { Vue, Component } from 'vue-property-decorator'
@Component
export default class PageName extends Vue {
}
</script>
