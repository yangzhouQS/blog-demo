<template>
  <div>My component</div>
</template>

<script lang="ts">
import { Vue, Component } from 'vue-property-decorator'
@Component
export default class ComponentName extends Vue {
}
</script>
