---
home: true
heroText: Luckysheet
tagline: Luckysheet 配置文档/API/教程
actionText: 快速上手 →
actionLink: /guide/
features:
- title: 功能强大
  details: 包含大量常用电子表格功能,替代你的excel
- title: 配置简单
  details: 最少的配置就能开始上手使用
- title: 完全开源
  details: 社区驱动,共同来完善你的想法
footer: MIT Licensed | Copyright © 2020-present Mengshukeji
---