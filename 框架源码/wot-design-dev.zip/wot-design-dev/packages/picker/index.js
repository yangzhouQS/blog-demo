import Picker from './src/main.vue'

Picker.install = Vue => {
  Vue.component(Picker.name, Picker)
}

export default Picker
