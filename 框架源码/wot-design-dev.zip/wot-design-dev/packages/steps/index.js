import Steps from './src/main.vue'

Steps.install = Vue => {
  Vue.component(Steps.name, Steps)
}

export default Steps
