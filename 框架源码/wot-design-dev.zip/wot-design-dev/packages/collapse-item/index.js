import CollapseItem from './src/main.vue'

CollapseItem.install = Vue => {
  Vue.component(CollapseItem.name, CollapseItem)
}

export default CollapseItem
