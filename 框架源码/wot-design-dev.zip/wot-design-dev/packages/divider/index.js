import Divider from './src/main.vue'

Divider.install = Vue => {
  Vue.component(Divider.name, Divider)
}

export default Divider
