import Collapse from './src/main.vue'

Collapse.install = Vue => {
  Vue.component(Collapse.name, Collapse)
}

export default Collapse
