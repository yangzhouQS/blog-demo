import Swipe from './src/main.vue'

Swipe.install = Vue => {
  Vue.component(Swipe.name, Swipe)
}

export default Swipe
