import SortButton from './src/main'

SortButton.install = Vue => {
  Vue.component(SortButton.name, SortButton)
}

export default SortButton
