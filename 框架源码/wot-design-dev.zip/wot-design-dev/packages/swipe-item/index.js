import SwipeItem from './src/main.vue'

SwipeItem.install = Vue => {
  Vue.component(SwipeItem.name, SwipeItem)
}

export default SwipeItem
