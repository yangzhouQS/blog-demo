import Popup from './src/main.vue'

Popup.install = Vue => {
  Vue.component(Popup.name, Popup)
}

export default Popup
