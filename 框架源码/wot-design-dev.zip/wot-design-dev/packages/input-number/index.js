import InputNumber from './src/main.vue'

InputNumber.install = Vue => {
  Vue.component(InputNumber.name, InputNumber)
}

export default InputNumber
