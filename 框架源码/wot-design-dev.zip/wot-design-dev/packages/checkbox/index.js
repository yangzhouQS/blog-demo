import Checkbox from './src/main.vue'

Checkbox.install = Vue => {
  Vue.component(Checkbox.name, Checkbox)
}

export default Checkbox
