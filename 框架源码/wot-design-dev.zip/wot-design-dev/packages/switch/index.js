import Switch from './src/main.vue'

Switch.install = Vue => {
  Vue.component(Switch.name, Switch)
}

export default Switch
