export default {
  label: String,
  labelWidth: String,
  disabled: Boolean,
  readonly: Boolean,
  placeholder: String,
  title: String,
  alignRight: Boolean,
  error: Boolean,
  required: Boolean,
  size: String
}
