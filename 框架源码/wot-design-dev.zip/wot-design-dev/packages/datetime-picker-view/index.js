import DatetimePickerView from './src/main.vue'

DatetimePickerView.install = Vue => {
  Vue.component(DatetimePickerView.name, DatetimePickerView)
}

export default DatetimePickerView
