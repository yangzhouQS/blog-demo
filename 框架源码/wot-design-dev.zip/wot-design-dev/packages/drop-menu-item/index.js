import DropMenuItem from './src/main.vue'

DropMenuItem.install = Vue => {
  Vue.component(DropMenuItem.name, DropMenuItem)
}

export default DropMenuItem
