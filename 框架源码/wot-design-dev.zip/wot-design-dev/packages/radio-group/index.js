import RadioGroup from './src/main.vue'

RadioGroup.install = Vue => {
  Vue.component(RadioGroup.name, RadioGroup)
}

export default RadioGroup
