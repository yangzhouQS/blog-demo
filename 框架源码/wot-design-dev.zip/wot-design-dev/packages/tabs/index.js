import Tabs from './src/main.vue'

Tabs.install = Vue => {
  Vue.component(Tabs.name, Tabs)
}

export default Tabs
