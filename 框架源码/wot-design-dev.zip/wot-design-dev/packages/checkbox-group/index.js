import CheckboxGroup from './src/main.vue'

CheckboxGroup.install = Vue => {
  Vue.component(CheckboxGroup.name, CheckboxGroup)
}

export default CheckboxGroup
