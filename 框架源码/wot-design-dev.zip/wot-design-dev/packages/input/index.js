import Input from './src/main.vue'

Input.install = Vue => {
  Vue.component(Input.name, Input)
}

export default Input
