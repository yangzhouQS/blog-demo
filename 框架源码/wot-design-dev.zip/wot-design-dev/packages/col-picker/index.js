import Address from './src/main.vue'

Address.install = Vue => {
  Vue.component(Address.name, Address)
}

export default Address
