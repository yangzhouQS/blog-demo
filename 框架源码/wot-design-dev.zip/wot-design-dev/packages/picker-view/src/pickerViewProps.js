export default {
  loading: Boolean,
  arrowHtml: {
    type: Boolean,
    default: true
  },
  columnsHeight: {
    type: Number,
    default: 217
  },
  loadingColor: String
}
