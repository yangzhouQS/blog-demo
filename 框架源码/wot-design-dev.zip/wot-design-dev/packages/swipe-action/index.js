import SwipeAction from './src/main.vue'

SwipeAction.install = Vue => {
  Vue.component(SwipeAction.name, SwipeAction)
}

export default SwipeAction
