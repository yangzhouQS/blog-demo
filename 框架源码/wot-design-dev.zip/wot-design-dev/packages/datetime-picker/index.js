import DatetimePicker from './src/main.vue'

DatetimePicker.install = Vue => {
  Vue.component(DatetimePicker.name, DatetimePicker)
}

export default DatetimePicker
