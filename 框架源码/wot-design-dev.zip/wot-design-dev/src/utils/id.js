const context = {
  id: 1000
}

export default context
