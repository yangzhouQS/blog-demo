<template>
  <div class="page-divider">
    <demo-block title="基本用法" transparent>
      <wd-divider>这是分割线</wd-divider>
    </demo-block>
    <demo-block title="自定义颜色" transparent>
      <wd-divider color="#4D80F0">自定义颜色</wd-divider>
    </demo-block>
  </div>
</template>