import Divider from './divider.vue';

export default Divider;