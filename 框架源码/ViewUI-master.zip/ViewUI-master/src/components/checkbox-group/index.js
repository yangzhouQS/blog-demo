import CheckboxGroup from '../checkbox/checkbox-group.vue';

export default CheckboxGroup;