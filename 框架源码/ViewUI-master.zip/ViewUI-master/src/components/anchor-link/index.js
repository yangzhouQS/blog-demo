import AnchorLink from '../anchor/anchor-link.vue';
export default AnchorLink;
