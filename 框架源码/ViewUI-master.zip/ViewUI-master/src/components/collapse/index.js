import Collapse from './collapse.vue';
import Panel from './panel.vue';

Collapse.Panel = Panel;
export default Collapse;