import Cell from './cell.vue';
import CellGroup from './cell-group.vue';

Cell.Group = CellGroup;
export default Cell;