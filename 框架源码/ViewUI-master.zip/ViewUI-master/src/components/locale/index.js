import locale from '../../locale/index';

export default locale.use;