import FormItem from '../form/form-item.vue';

export default FormItem;