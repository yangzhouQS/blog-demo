import BreadcrumbItem from '../breadcrumb/breadcrumb-item.vue';

export default BreadcrumbItem;