import Avatar from './avatar.vue';
export default Avatar;