import ButtonGroup from '../button/button-group.vue';

export default ButtonGroup;