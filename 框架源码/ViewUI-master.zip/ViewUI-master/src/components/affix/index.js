import Affix from './affix.vue';
export default Affix;