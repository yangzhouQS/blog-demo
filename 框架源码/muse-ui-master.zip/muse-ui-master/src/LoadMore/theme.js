export default theme => {
  return `
  .mu-refresh-control{
    color: ${theme.primary};
  }
  `;
};
