export default (theme) => {
  return `
  .mu-sub-header {
    color: ${theme.text.secondary};
  }
  `;
};
