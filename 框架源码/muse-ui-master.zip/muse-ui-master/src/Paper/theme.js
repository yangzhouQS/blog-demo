export default (theme) => {
  return `
  .mu-paper {
    color: ${theme.text.primary};
    background-color: ${theme.background.paper};
  }
  `;
};
