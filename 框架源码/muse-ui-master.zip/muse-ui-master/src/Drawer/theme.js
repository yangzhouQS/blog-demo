export default (theme) => {
  return `
  .mu-drawer {
    background-color: ${theme.background.paper};
  }
  `;
};
