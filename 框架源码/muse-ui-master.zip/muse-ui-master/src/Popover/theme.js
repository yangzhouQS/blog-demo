export default (theme) => {
  return `
  .mu-popover{
    background: ${theme.background.paper};
  }
  `;
};
