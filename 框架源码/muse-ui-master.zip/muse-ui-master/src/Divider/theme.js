export default (theme) => {
  return `
  .mu-divider {
    background-color: ${theme.divider};
  }
  `;
};
