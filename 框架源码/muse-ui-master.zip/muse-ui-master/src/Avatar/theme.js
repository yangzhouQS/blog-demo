export default (theme) => {
  return `
    .mu-avatar {
      background-color: ${theme.track};
      color: ${theme.text.alternate};
    }
  `;
};

