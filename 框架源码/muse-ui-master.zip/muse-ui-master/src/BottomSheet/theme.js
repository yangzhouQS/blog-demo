export default (theme) => {
  return `
    .mu-bottom-sheet {
      background-color: ${theme.background.paper};
    }
  `;
};
