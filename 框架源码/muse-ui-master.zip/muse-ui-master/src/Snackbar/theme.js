export default (theme) => {
  return `
  .mu-snackbar {
    color: ${theme.text.alternate};
    background-color: ${theme.text.primary};
  }
  `;
};
