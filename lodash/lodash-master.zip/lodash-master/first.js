export { default } from './head.js'
