/** Used to match template delimiters. */
const reEvaluate = /<%([\s\S]+?)%>/g

export default reEvaluate
