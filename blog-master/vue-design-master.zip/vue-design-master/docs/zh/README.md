# 江山父老能容我 不使人间造孽钱

[点击查看啊【捐赠列表】](/zh/donor-list.md)

## 微信
<img width="300" src="@as/weixin.jpg">

## 支付宝
<img width="300" src="@as/zfb.jpg">
